﻿namespace EntityFramework
{
    partial class forgotPswForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.forgotPswStatuCombobox = new System.Windows.Forms.ComboBox();
            this.forgotPswIdTextbox = new System.Windows.Forms.TextBox();
            this.forgotPswSecurityWordTextbox = new System.Windows.Forms.TextBox();
            this.forgotPswCheckBtn = new System.Windows.Forms.Button();
            this.forgotPswStatuLabel = new System.Windows.Forms.Label();
            this.forgotPswIdLabel = new System.Windows.Forms.Label();
            this.forgotPswSecurityWordLabel = new System.Windows.Forms.Label();
            this.forgotPswControlPanel = new System.Windows.Forms.Panel();
            this.ForgotPswGroupbox = new System.Windows.Forms.GroupBox();
            this.forgotPswTsPswResetPanel = new System.Windows.Forms.Panel();
            this.forgotPswTSNewPswGroupbox = new System.Windows.Forms.GroupBox();
            this.forgotPswTSNewPswBtn = new System.Windows.Forms.Button();
            this.forgotPswTSNewPsw2Label = new System.Windows.Forms.Label();
            this.forgotPswTSNewPsw1Label = new System.Windows.Forms.Label();
            this.forgotPswTSNewPsw2Textbox = new System.Windows.Forms.TextBox();
            this.forgotPswTSNewPsw1Textbox = new System.Windows.Forms.TextBox();
            this.forgotPswSTDResetPswPanel = new System.Windows.Forms.Panel();
            this.forgotPswSTDResetGropbox = new System.Windows.Forms.GroupBox();
            this.forgotPswSTDNewPswBtn = new System.Windows.Forms.Button();
            this.forgotPswSTDNewPsw2Label = new System.Windows.Forms.Label();
            this.forgotPswSTDNewPsw1Label = new System.Windows.Forms.Label();
            this.forgotPswSTDNewPsw2Textbox = new System.Windows.Forms.TextBox();
            this.forgotPswSTDNewPsw1Textbox = new System.Windows.Forms.TextBox();
            this.forgotPswControlPanel.SuspendLayout();
            this.ForgotPswGroupbox.SuspendLayout();
            this.forgotPswTsPswResetPanel.SuspendLayout();
            this.forgotPswTSNewPswGroupbox.SuspendLayout();
            this.forgotPswSTDResetPswPanel.SuspendLayout();
            this.forgotPswSTDResetGropbox.SuspendLayout();
            this.SuspendLayout();
            // 
            // forgotPswStatuCombobox
            // 
            this.forgotPswStatuCombobox.FormattingEnabled = true;
            this.forgotPswStatuCombobox.Items.AddRange(new object[] {
            "Öğretmen",
            "Öğrenci"});
            this.forgotPswStatuCombobox.Location = new System.Drawing.Point(186, 38);
            this.forgotPswStatuCombobox.Name = "forgotPswStatuCombobox";
            this.forgotPswStatuCombobox.Size = new System.Drawing.Size(167, 24);
            this.forgotPswStatuCombobox.TabIndex = 0;
            // 
            // forgotPswIdTextbox
            // 
            this.forgotPswIdTextbox.Location = new System.Drawing.Point(186, 86);
            this.forgotPswIdTextbox.Name = "forgotPswIdTextbox";
            this.forgotPswIdTextbox.Size = new System.Drawing.Size(167, 22);
            this.forgotPswIdTextbox.TabIndex = 1;
            // 
            // forgotPswSecurityWordTextbox
            // 
            this.forgotPswSecurityWordTextbox.Location = new System.Drawing.Point(186, 137);
            this.forgotPswSecurityWordTextbox.Name = "forgotPswSecurityWordTextbox";
            this.forgotPswSecurityWordTextbox.Size = new System.Drawing.Size(167, 22);
            this.forgotPswSecurityWordTextbox.TabIndex = 2;
            // 
            // forgotPswCheckBtn
            // 
            this.forgotPswCheckBtn.Location = new System.Drawing.Point(186, 202);
            this.forgotPswCheckBtn.Name = "forgotPswCheckBtn";
            this.forgotPswCheckBtn.Size = new System.Drawing.Size(167, 33);
            this.forgotPswCheckBtn.TabIndex = 3;
            this.forgotPswCheckBtn.Text = "Gönder";
            this.forgotPswCheckBtn.UseVisualStyleBackColor = true;
            this.forgotPswCheckBtn.Click += new System.EventHandler(this.forgotPswCheckBtn_Click);
            // 
            // forgotPswStatuLabel
            // 
            this.forgotPswStatuLabel.AutoSize = true;
            this.forgotPswStatuLabel.Location = new System.Drawing.Point(41, 38);
            this.forgotPswStatuLabel.Name = "forgotPswStatuLabel";
            this.forgotPswStatuLabel.Size = new System.Drawing.Size(53, 17);
            this.forgotPswStatuLabel.TabIndex = 4;
            this.forgotPswStatuLabel.Text = "Statu : ";
            // 
            // forgotPswIdLabel
            // 
            this.forgotPswIdLabel.AutoSize = true;
            this.forgotPswIdLabel.Location = new System.Drawing.Point(41, 91);
            this.forgotPswIdLabel.Name = "forgotPswIdLabel";
            this.forgotPswIdLabel.Size = new System.Drawing.Size(27, 17);
            this.forgotPswIdLabel.TabIndex = 5;
            this.forgotPswIdLabel.Text = "İd :";
            // 
            // forgotPswSecurityWordLabel
            // 
            this.forgotPswSecurityWordLabel.AutoSize = true;
            this.forgotPswSecurityWordLabel.Location = new System.Drawing.Point(41, 137);
            this.forgotPswSecurityWordLabel.Name = "forgotPswSecurityWordLabel";
            this.forgotPswSecurityWordLabel.Size = new System.Drawing.Size(131, 17);
            this.forgotPswSecurityWordLabel.TabIndex = 6;
            this.forgotPswSecurityWordLabel.Text = "Güvenlik Kelimesi : ";
            // 
            // forgotPswControlPanel
            // 
            this.forgotPswControlPanel.Controls.Add(this.ForgotPswGroupbox);
            this.forgotPswControlPanel.Location = new System.Drawing.Point(67, 40);
            this.forgotPswControlPanel.Name = "forgotPswControlPanel";
            this.forgotPswControlPanel.Size = new System.Drawing.Size(735, 460);
            this.forgotPswControlPanel.TabIndex = 7;
            // 
            // ForgotPswGroupbox
            // 
            this.ForgotPswGroupbox.Controls.Add(this.forgotPswSecurityWordLabel);
            this.ForgotPswGroupbox.Controls.Add(this.forgotPswIdLabel);
            this.ForgotPswGroupbox.Controls.Add(this.forgotPswStatuLabel);
            this.ForgotPswGroupbox.Controls.Add(this.forgotPswCheckBtn);
            this.ForgotPswGroupbox.Controls.Add(this.forgotPswSecurityWordTextbox);
            this.ForgotPswGroupbox.Controls.Add(this.forgotPswIdTextbox);
            this.ForgotPswGroupbox.Controls.Add(this.forgotPswStatuCombobox);
            this.ForgotPswGroupbox.Location = new System.Drawing.Point(165, 94);
            this.ForgotPswGroupbox.Name = "ForgotPswGroupbox";
            this.ForgotPswGroupbox.Size = new System.Drawing.Size(403, 271);
            this.ForgotPswGroupbox.TabIndex = 7;
            this.ForgotPswGroupbox.TabStop = false;
            this.ForgotPswGroupbox.Text = "Şifremi Unuttum";
            // 
            // forgotPswTsPswResetPanel
            // 
            this.forgotPswTsPswResetPanel.Controls.Add(this.forgotPswTSNewPswGroupbox);
            this.forgotPswTsPswResetPanel.Location = new System.Drawing.Point(67, 40);
            this.forgotPswTsPswResetPanel.Name = "forgotPswTsPswResetPanel";
            this.forgotPswTsPswResetPanel.Size = new System.Drawing.Size(735, 460);
            this.forgotPswTsPswResetPanel.TabIndex = 8;
            // 
            // forgotPswTSNewPswGroupbox
            // 
            this.forgotPswTSNewPswGroupbox.Controls.Add(this.forgotPswTSNewPswBtn);
            this.forgotPswTSNewPswGroupbox.Controls.Add(this.forgotPswTSNewPsw2Label);
            this.forgotPswTSNewPswGroupbox.Controls.Add(this.forgotPswTSNewPsw1Label);
            this.forgotPswTSNewPswGroupbox.Controls.Add(this.forgotPswTSNewPsw2Textbox);
            this.forgotPswTSNewPswGroupbox.Controls.Add(this.forgotPswTSNewPsw1Textbox);
            this.forgotPswTSNewPswGroupbox.Location = new System.Drawing.Point(103, 95);
            this.forgotPswTSNewPswGroupbox.Name = "forgotPswTSNewPswGroupbox";
            this.forgotPswTSNewPswGroupbox.Size = new System.Drawing.Size(476, 236);
            this.forgotPswTSNewPswGroupbox.TabIndex = 5;
            this.forgotPswTSNewPswGroupbox.TabStop = false;
            this.forgotPswTSNewPswGroupbox.Text = "ŞİFREMİ YENİLE";
            // 
            // forgotPswTSNewPswBtn
            // 
            this.forgotPswTSNewPswBtn.Location = new System.Drawing.Point(143, 155);
            this.forgotPswTSNewPswBtn.Name = "forgotPswTSNewPswBtn";
            this.forgotPswTSNewPswBtn.Size = new System.Drawing.Size(230, 41);
            this.forgotPswTSNewPswBtn.TabIndex = 2;
            this.forgotPswTSNewPswBtn.Text = "Yenile";
            this.forgotPswTSNewPswBtn.UseVisualStyleBackColor = true;
            this.forgotPswTSNewPswBtn.Click += new System.EventHandler(this.forgotPswTSNewPswBtn_Click);
            // 
            // forgotPswTSNewPsw2Label
            // 
            this.forgotPswTSNewPsw2Label.AutoSize = true;
            this.forgotPswTSNewPsw2Label.Location = new System.Drawing.Point(39, 103);
            this.forgotPswTSNewPsw2Label.Name = "forgotPswTSNewPsw2Label";
            this.forgotPswTSNewPsw2Label.Size = new System.Drawing.Size(95, 17);
            this.forgotPswTSNewPsw2Label.TabIndex = 3;
            this.forgotPswTSNewPsw2Label.Text = "Şifre Tekrar : ";
            // 
            // forgotPswTSNewPsw1Label
            // 
            this.forgotPswTSNewPsw1Label.AutoSize = true;
            this.forgotPswTSNewPsw1Label.Location = new System.Drawing.Point(39, 45);
            this.forgotPswTSNewPsw1Label.Name = "forgotPswTSNewPsw1Label";
            this.forgotPswTSNewPsw1Label.Size = new System.Drawing.Size(49, 17);
            this.forgotPswTSNewPsw1Label.TabIndex = 4;
            this.forgotPswTSNewPsw1Label.Text = "Şifre : ";
            // 
            // forgotPswTSNewPsw2Textbox
            // 
            this.forgotPswTSNewPsw2Textbox.Location = new System.Drawing.Point(143, 100);
            this.forgotPswTSNewPsw2Textbox.Name = "forgotPswTSNewPsw2Textbox";
            this.forgotPswTSNewPsw2Textbox.Size = new System.Drawing.Size(230, 22);
            this.forgotPswTSNewPsw2Textbox.TabIndex = 1;
            // 
            // forgotPswTSNewPsw1Textbox
            // 
            this.forgotPswTSNewPsw1Textbox.Location = new System.Drawing.Point(143, 45);
            this.forgotPswTSNewPsw1Textbox.Name = "forgotPswTSNewPsw1Textbox";
            this.forgotPswTSNewPsw1Textbox.Size = new System.Drawing.Size(227, 22);
            this.forgotPswTSNewPsw1Textbox.TabIndex = 0;
            // 
            // forgotPswSTDResetPswPanel
            // 
            this.forgotPswSTDResetPswPanel.Controls.Add(this.forgotPswSTDResetGropbox);
            this.forgotPswSTDResetPswPanel.Location = new System.Drawing.Point(67, 40);
            this.forgotPswSTDResetPswPanel.Name = "forgotPswSTDResetPswPanel";
            this.forgotPswSTDResetPswPanel.Size = new System.Drawing.Size(735, 460);
            this.forgotPswSTDResetPswPanel.TabIndex = 9;
            // 
            // forgotPswSTDResetGropbox
            // 
            this.forgotPswSTDResetGropbox.Controls.Add(this.forgotPswSTDNewPswBtn);
            this.forgotPswSTDResetGropbox.Controls.Add(this.forgotPswSTDNewPsw2Label);
            this.forgotPswSTDResetGropbox.Controls.Add(this.forgotPswSTDNewPsw1Label);
            this.forgotPswSTDResetGropbox.Controls.Add(this.forgotPswSTDNewPsw2Textbox);
            this.forgotPswSTDResetGropbox.Controls.Add(this.forgotPswSTDNewPsw1Textbox);
            this.forgotPswSTDResetGropbox.Location = new System.Drawing.Point(103, 95);
            this.forgotPswSTDResetGropbox.Name = "forgotPswSTDResetGropbox";
            this.forgotPswSTDResetGropbox.Size = new System.Drawing.Size(476, 236);
            this.forgotPswSTDResetGropbox.TabIndex = 5;
            this.forgotPswSTDResetGropbox.TabStop = false;
            this.forgotPswSTDResetGropbox.Text = "ŞİFREMİ YENİLE";
            // 
            // forgotPswSTDNewPswBtn
            // 
            this.forgotPswSTDNewPswBtn.Location = new System.Drawing.Point(143, 155);
            this.forgotPswSTDNewPswBtn.Name = "forgotPswSTDNewPswBtn";
            this.forgotPswSTDNewPswBtn.Size = new System.Drawing.Size(230, 41);
            this.forgotPswSTDNewPswBtn.TabIndex = 2;
            this.forgotPswSTDNewPswBtn.Text = "Yenile";
            this.forgotPswSTDNewPswBtn.UseVisualStyleBackColor = true;
            this.forgotPswSTDNewPswBtn.Click += new System.EventHandler(this.forgotPswSTDNewPswBtn_Click);
            // 
            // forgotPswSTDNewPsw2Label
            // 
            this.forgotPswSTDNewPsw2Label.AutoSize = true;
            this.forgotPswSTDNewPsw2Label.Location = new System.Drawing.Point(39, 103);
            this.forgotPswSTDNewPsw2Label.Name = "forgotPswSTDNewPsw2Label";
            this.forgotPswSTDNewPsw2Label.Size = new System.Drawing.Size(95, 17);
            this.forgotPswSTDNewPsw2Label.TabIndex = 3;
            this.forgotPswSTDNewPsw2Label.Text = "Şifre Tekrar : ";
            // 
            // forgotPswSTDNewPsw1Label
            // 
            this.forgotPswSTDNewPsw1Label.AutoSize = true;
            this.forgotPswSTDNewPsw1Label.Location = new System.Drawing.Point(39, 45);
            this.forgotPswSTDNewPsw1Label.Name = "forgotPswSTDNewPsw1Label";
            this.forgotPswSTDNewPsw1Label.Size = new System.Drawing.Size(49, 17);
            this.forgotPswSTDNewPsw1Label.TabIndex = 4;
            this.forgotPswSTDNewPsw1Label.Text = "Şifre : ";
            // 
            // forgotPswSTDNewPsw2Textbox
            // 
            this.forgotPswSTDNewPsw2Textbox.Location = new System.Drawing.Point(143, 100);
            this.forgotPswSTDNewPsw2Textbox.Name = "forgotPswSTDNewPsw2Textbox";
            this.forgotPswSTDNewPsw2Textbox.Size = new System.Drawing.Size(230, 22);
            this.forgotPswSTDNewPsw2Textbox.TabIndex = 1;
            // 
            // forgotPswSTDNewPsw1Textbox
            // 
            this.forgotPswSTDNewPsw1Textbox.Location = new System.Drawing.Point(143, 45);
            this.forgotPswSTDNewPsw1Textbox.Name = "forgotPswSTDNewPsw1Textbox";
            this.forgotPswSTDNewPsw1Textbox.Size = new System.Drawing.Size(227, 22);
            this.forgotPswSTDNewPsw1Textbox.TabIndex = 0;
            // 
            // forgotPswForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(888, 550);
            this.Controls.Add(this.forgotPswControlPanel);
            this.Controls.Add(this.forgotPswSTDResetPswPanel);
            this.Controls.Add(this.forgotPswTsPswResetPanel);
            this.Name = "forgotPswForm";
            this.Text = "forgotPswForm";
            this.Load += new System.EventHandler(this.forgotPswForm_Load);
            this.forgotPswControlPanel.ResumeLayout(false);
            this.ForgotPswGroupbox.ResumeLayout(false);
            this.ForgotPswGroupbox.PerformLayout();
            this.forgotPswTsPswResetPanel.ResumeLayout(false);
            this.forgotPswTSNewPswGroupbox.ResumeLayout(false);
            this.forgotPswTSNewPswGroupbox.PerformLayout();
            this.forgotPswSTDResetPswPanel.ResumeLayout(false);
            this.forgotPswSTDResetGropbox.ResumeLayout(false);
            this.forgotPswSTDResetGropbox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox forgotPswStatuCombobox;
        private System.Windows.Forms.TextBox forgotPswIdTextbox;
        private System.Windows.Forms.TextBox forgotPswSecurityWordTextbox;
        private System.Windows.Forms.Button forgotPswCheckBtn;
        private System.Windows.Forms.Label forgotPswStatuLabel;
        private System.Windows.Forms.Label forgotPswIdLabel;
        private System.Windows.Forms.Label forgotPswSecurityWordLabel;
        private System.Windows.Forms.Panel forgotPswControlPanel;
        private System.Windows.Forms.GroupBox ForgotPswGroupbox;
        private System.Windows.Forms.Panel forgotPswTsPswResetPanel;
        private System.Windows.Forms.GroupBox forgotPswTSNewPswGroupbox;
        private System.Windows.Forms.Button forgotPswTSNewPswBtn;
        private System.Windows.Forms.Label forgotPswTSNewPsw2Label;
        private System.Windows.Forms.Label forgotPswTSNewPsw1Label;
        private System.Windows.Forms.TextBox forgotPswTSNewPsw2Textbox;
        private System.Windows.Forms.TextBox forgotPswTSNewPsw1Textbox;
        private System.Windows.Forms.Panel forgotPswSTDResetPswPanel;
        private System.Windows.Forms.GroupBox forgotPswSTDResetGropbox;
        private System.Windows.Forms.Button forgotPswSTDNewPswBtn;
        private System.Windows.Forms.Label forgotPswSTDNewPsw2Label;
        private System.Windows.Forms.Label forgotPswSTDNewPsw1Label;
        private System.Windows.Forms.TextBox forgotPswSTDNewPsw2Textbox;
        private System.Windows.Forms.TextBox forgotPswSTDNewPsw1Textbox;
    }
}