﻿namespace EntityFramework
{
    partial class aaa
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.loginPanel = new System.Windows.Forms.Panel();
            this.LogInGroupBox = new System.Windows.Forms.GroupBox();
            this.loginPanelPswPanel = new System.Windows.Forms.Panel();
            this.loginPanelİdPanel = new System.Windows.Forms.Panel();
            this.forgotPswBtn = new System.Windows.Forms.Button();
            this.STATUpictureBox = new System.Windows.Forms.PictureBox();
            this.PSWpictureBox = new System.Windows.Forms.PictureBox();
            this.IDpictureBox = new System.Windows.Forms.PictureBox();
            this.STATUcomboBox = new System.Windows.Forms.ComboBox();
            this.PSWtxtbox = new System.Windows.Forms.TextBox();
            this.IDtxtbox = new System.Windows.Forms.TextBox();
            this.LogInbtn = new System.Windows.Forms.Button();
            this.adminPanel = new System.Windows.Forms.Panel();
            this.adminControlPanelGroupbox = new System.Windows.Forms.GroupBox();
            this.adminPanelPeriodFinish = new System.Windows.Forms.Button();
            this.logOutbtn = new System.Windows.Forms.Button();
            this.deletebtn = new System.Windows.Forms.Button();
            this.studentAddPanelBtn = new System.Windows.Forms.Button();
            this.studentsbtn = new System.Windows.Forms.Button();
            this.teachingstaffsbtn = new System.Windows.Forms.Button();
            this.teachingstaffaddPanelbtn = new System.Windows.Forms.Button();
            this.teachingstaffAddpanel = new System.Windows.Forms.Panel();
            this.Teachingstaffaddgroupbox = new System.Windows.Forms.GroupBox();
            this.TSsecurityWordLabel = new System.Windows.Forms.Label();
            this.TSsecurityWordTextbox = new System.Windows.Forms.TextBox();
            this.TSaddPanelBackbtn = new System.Windows.Forms.Button();
            this.TSaddBTN = new System.Windows.Forms.Button();
            this.TStc_noLabel = new System.Windows.Forms.Label();
            this.TSpswlabel = new System.Windows.Forms.Label();
            this.TSsurnamelabel = new System.Windows.Forms.Label();
            this.TSnamelabel = new System.Windows.Forms.Label();
            this.TSprogramsLabel = new System.Windows.Forms.Label();
            this.TSprogramsCombobox = new System.Windows.Forms.ComboBox();
            this.TSsurnameTxtbox = new System.Windows.Forms.TextBox();
            this.TStc_noTxtbox = new System.Windows.Forms.TextBox();
            this.TSpswTxtbox = new System.Windows.Forms.TextBox();
            this.TSnameTxtbox = new System.Windows.Forms.TextBox();
            this.StdaddPanel = new System.Windows.Forms.Panel();
            this.stdAddGroupbox = new System.Windows.Forms.GroupBox();
            this.stdSecurityWordLabel = new System.Windows.Forms.Label();
            this.stdSecurityWordTextbox = new System.Windows.Forms.TextBox();
            this.stdAddPanelBackBtn = new System.Windows.Forms.Button();
            this.stdAddBtn = new System.Windows.Forms.Button();
            this.stdProgramsLabel = new System.Windows.Forms.Label();
            this.stdPswLabel = new System.Windows.Forms.Label();
            this.stdTc_noLabel = new System.Windows.Forms.Label();
            this.stdSurnameLabel = new System.Windows.Forms.Label();
            this.stdNameLabel = new System.Windows.Forms.Label();
            this.stdProgramsCombobox = new System.Windows.Forms.ComboBox();
            this.stdPswTxtbox = new System.Windows.Forms.TextBox();
            this.stdSurnameTxtbox = new System.Windows.Forms.TextBox();
            this.stdTc_noTxtbox = new System.Windows.Forms.TextBox();
            this.stdNameTxtbox = new System.Windows.Forms.TextBox();
            this.dellPanel = new System.Windows.Forms.Panel();
            this.dellGroupbox = new System.Windows.Forms.GroupBox();
            this.dellDatagridView = new System.Windows.Forms.DataGridView();
            this.dellInputGroupbox = new System.Windows.Forms.GroupBox();
            this.dellPanelBackBtn = new System.Windows.Forms.Button();
            this.dellBtn = new System.Windows.Forms.Button();
            this.dellIdLabel = new System.Windows.Forms.Label();
            this.dellStatuLabel = new System.Windows.Forms.Label();
            this.dellIdTxtbox = new System.Windows.Forms.TextBox();
            this.dellStatuCombobox = new System.Windows.Forms.ComboBox();
            this.TSgridViewPanel = new System.Windows.Forms.Panel();
            this.TSgridViewUpdateGroupbox = new System.Windows.Forms.GroupBox();
            this.TSgridViewUpdateBtn = new System.Windows.Forms.Button();
            this.TSgridViewBackBtn = new System.Windows.Forms.Button();
            this.TSgridViewUpdateTcNoLabel = new System.Windows.Forms.Label();
            this.TSgridViewUpdateSurnameLabel = new System.Windows.Forms.Label();
            this.TSgridViewUpdateNameLabel = new System.Windows.Forms.Label();
            this.TSgridViewUpdateTCNoTextbox = new System.Windows.Forms.TextBox();
            this.TSgridViewUpdateNameTextbox = new System.Windows.Forms.TextBox();
            this.TSgridViewUpdateSurnameTextbox = new System.Windows.Forms.TextBox();
            this.TSsearchGroupbox = new System.Windows.Forms.GroupBox();
            this.TSgridViewSearchbtn = new System.Windows.Forms.Button();
            this.TSgridViewSearchLabel = new System.Windows.Forms.Label();
            this.TSgridViewSearchTxtbox = new System.Windows.Forms.TextBox();
            this.TSgridViewGroupbox = new System.Windows.Forms.GroupBox();
            this.TSgridView = new System.Windows.Forms.DataGridView();
            this.stdGridViewPanel = new System.Windows.Forms.Panel();
            this.stdGridviewUpdateGroupbox = new System.Windows.Forms.GroupBox();
            this.stdGridViewUpdateBtn = new System.Windows.Forms.Button();
            this.stdGridViewBackBtn = new System.Windows.Forms.Button();
            this.stdGridViewUpdateTCNoLabel = new System.Windows.Forms.Label();
            this.stdGridViewUpdateSurnameLabel = new System.Windows.Forms.Label();
            this.stdGridViewUpdateNameLabel = new System.Windows.Forms.Label();
            this.stdGridViewUpdateTCNoTextbox = new System.Windows.Forms.TextBox();
            this.stdGridViewUpdateNameTextbox = new System.Windows.Forms.TextBox();
            this.stdGridViewUpdateSurnameTextbox = new System.Windows.Forms.TextBox();
            this.stdGridViewSearchGroupbox = new System.Windows.Forms.GroupBox();
            this.stdGridViewSearchBtn = new System.Windows.Forms.Button();
            this.stdGridViewSearcLabel = new System.Windows.Forms.Label();
            this.stdGridViewSearchTxtbox = new System.Windows.Forms.TextBox();
            this.stdGridViewGroupbox = new System.Windows.Forms.GroupBox();
            this.stdDataGridView = new System.Windows.Forms.DataGridView();
            this.TScontrolPanel = new System.Windows.Forms.Panel();
            this.TScontrolGroupbox = new System.Windows.Forms.GroupBox();
            this.TSlecturesPanel = new System.Windows.Forms.Panel();
            this.TSlecturesGroupbox = new System.Windows.Forms.GroupBox();
            this.TSLecturesListView = new System.Windows.Forms.ListView();
            this.TSpointsPanel = new System.Windows.Forms.Panel();
            this.TSpointsAddGroupbox2 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.TSpointsAddListview = new System.Windows.Forms.ListView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.TSpointsLecturesListView = new System.Windows.Forms.ListView();
            this.TSpointsAddGroupbox = new System.Windows.Forms.GroupBox();
            this.TSpointsAddFinalLabel = new System.Windows.Forms.Label();
            this.TSpointsAddVizeLabel = new System.Windows.Forms.Label();
            this.TSpointsAddFinalTextbox = new System.Windows.Forms.TextBox();
            this.TSpointsAddBtn = new System.Windows.Forms.Button();
            this.TSpointsAddVizeTextbox = new System.Windows.Forms.TextBox();
            this.TSProfilePanel = new System.Windows.Forms.Panel();
            this.TSProfileGroupbox = new System.Windows.Forms.GroupBox();
            this.TSProfileAddNewSecurityWordBtn = new System.Windows.Forms.Button();
            this.TSProfileAddNewPswBtn = new System.Windows.Forms.Button();
            this.TSProfileNewSecurityWordBtn = new System.Windows.Forms.Button();
            this.TSProfileNewPswBtn = new System.Windows.Forms.Button();
            this.TSProfileNewSecurityWordTextbox = new System.Windows.Forms.TextBox();
            this.TSProfileNewPswTextbox = new System.Windows.Forms.TextBox();
            this.TSProfileInputSecurityWordLabel = new System.Windows.Forms.Label();
            this.TSProfileInputPswLabel = new System.Windows.Forms.Label();
            this.TSProfileInputProgramsLabel = new System.Windows.Forms.Label();
            this.TSProfileInputSurnameLabel = new System.Windows.Forms.Label();
            this.TSProfileInputNameLabel = new System.Windows.Forms.Label();
            this.TSProfileSecurityWordLabel = new System.Windows.Forms.Label();
            this.TSProfilePswLabel = new System.Windows.Forms.Label();
            this.TSProfilProgramsLabel = new System.Windows.Forms.Label();
            this.TSProfileSurnameLabel = new System.Windows.Forms.Label();
            this.TSProfileNameLabel = new System.Windows.Forms.Label();
            this.TSAddLecturesPanel = new System.Windows.Forms.Panel();
            this.TSders_verListViewGroupbox = new System.Windows.Forms.GroupBox();
            this.TSders_verAddBtn = new System.Windows.Forms.Button();
            this.TSLectureAddListView = new System.Windows.Forms.ListView();
            this.TSotherGroupbox = new System.Windows.Forms.GroupBox();
            this.TSlecturesShowBtn = new System.Windows.Forms.Button();
            this.TSLoginWelcomeLabel = new System.Windows.Forms.Label();
            this.TSnoticePanelBtn = new System.Windows.Forms.Button();
            this.TSexamsPanelBtn = new System.Windows.Forms.Button();
            this.TSlecturesPanelBackBtn = new System.Windows.Forms.Button();
            this.TSLecturesaddbtn = new System.Windows.Forms.Button();
            this.stdControlPanel = new System.Windows.Forms.Panel();
            this.stdLecturesPanel = new System.Windows.Forms.Panel();
            this.stdLecturesShowGroupbox = new System.Windows.Forms.GroupBox();
            this.stdLecturesShowListView = new System.Windows.Forms.ListView();
            this.stdOldLecturesPanel = new System.Windows.Forms.Panel();
            this.stdOldLecturesListviewGroupbox = new System.Windows.Forms.GroupBox();
            this.stdOldLecturesPanellistView = new System.Windows.Forms.ListView();
            this.stdPointsPanel = new System.Windows.Forms.Panel();
            this.stdPointListViewGroupbox = new System.Windows.Forms.GroupBox();
            this.stdPointListView = new System.Windows.Forms.ListView();
            this.stdLecturesAddPanel = new System.Windows.Forms.Panel();
            this.stdLectureAddGroupbox = new System.Windows.Forms.GroupBox();
            this.stdLecturesAddBtn = new System.Windows.Forms.Button();
            this.stdLecturesAddListView = new System.Windows.Forms.ListView();
            this.stdProfilePanel = new System.Windows.Forms.Panel();
            this.stdProfileİnformationGroupbox = new System.Windows.Forms.GroupBox();
            this.stdNewPswBtn = new System.Windows.Forms.Button();
            this.stdNewSecurityWordBtn = new System.Windows.Forms.Button();
            this.stdNewSecurityWordTextbox = new System.Windows.Forms.TextBox();
            this.stdNewPswTextbox = new System.Windows.Forms.TextBox();
            this.stdProfileNewSecurityWordPanelBtn = new System.Windows.Forms.Button();
            this.stdProfileNewPswPanelBtn = new System.Windows.Forms.Button();
            this.stdProfileInputSecurityWordLabel = new System.Windows.Forms.Label();
            this.stdProfileInputPswLabel = new System.Windows.Forms.Label();
            this.stdProfileInputProgramsLabel = new System.Windows.Forms.Label();
            this.stdProfileInputsurnameLabel = new System.Windows.Forms.Label();
            this.stdProfileInputNameLabel = new System.Windows.Forms.Label();
            this.stdProfileSecurityWordLabel = new System.Windows.Forms.Label();
            this.stdProfilePswLabel = new System.Windows.Forms.Label();
            this.stdProfileProgramsLabel = new System.Windows.Forms.Label();
            this.stdProfileSurnameLabel = new System.Windows.Forms.Label();
            this.stdProfileNameLabel = new System.Windows.Forms.Label();
            this.stdControlTransactionGroupbox = new System.Windows.Forms.GroupBox();
            this.stdOldLecturesPanelbtn = new System.Windows.Forms.Button();
            this.stdControlPanelBackBtn = new System.Windows.Forms.Button();
            this.stdLecturesPanelBtn = new System.Windows.Forms.Button();
            this.stdProfilePanelBtn = new System.Windows.Forms.Button();
            this.stdLecturesAddPanelBtn = new System.Windows.Forms.Button();
            this.stdPointsPanelBtn = new System.Windows.Forms.Button();
            this.CloseBtn = new System.Windows.Forms.Button();
            this.periodPanel = new System.Windows.Forms.Panel();
            this.PeriodInsertGroupbox = new System.Windows.Forms.GroupBox();
            this.periodPanelBackBtn = new System.Windows.Forms.Button();
            this.PeriodInsertBtn = new System.Windows.Forms.Button();
            this.PeriodInsertNamecomboBox = new System.Windows.Forms.ComboBox();
            this.periodInsertNameLabel = new System.Windows.Forms.Label();
            this.stdOldLecturesAddBtn = new System.Windows.Forms.Button();
            this.loginPanel.SuspendLayout();
            this.LogInGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.STATUpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PSWpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.IDpictureBox)).BeginInit();
            this.adminPanel.SuspendLayout();
            this.adminControlPanelGroupbox.SuspendLayout();
            this.teachingstaffAddpanel.SuspendLayout();
            this.Teachingstaffaddgroupbox.SuspendLayout();
            this.StdaddPanel.SuspendLayout();
            this.stdAddGroupbox.SuspendLayout();
            this.dellPanel.SuspendLayout();
            this.dellGroupbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dellDatagridView)).BeginInit();
            this.dellInputGroupbox.SuspendLayout();
            this.TSgridViewPanel.SuspendLayout();
            this.TSgridViewUpdateGroupbox.SuspendLayout();
            this.TSsearchGroupbox.SuspendLayout();
            this.TSgridViewGroupbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TSgridView)).BeginInit();
            this.stdGridViewPanel.SuspendLayout();
            this.stdGridviewUpdateGroupbox.SuspendLayout();
            this.stdGridViewSearchGroupbox.SuspendLayout();
            this.stdGridViewGroupbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stdDataGridView)).BeginInit();
            this.TScontrolPanel.SuspendLayout();
            this.TScontrolGroupbox.SuspendLayout();
            this.TSlecturesPanel.SuspendLayout();
            this.TSlecturesGroupbox.SuspendLayout();
            this.TSpointsPanel.SuspendLayout();
            this.TSpointsAddGroupbox2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.TSpointsAddGroupbox.SuspendLayout();
            this.TSProfilePanel.SuspendLayout();
            this.TSProfileGroupbox.SuspendLayout();
            this.TSAddLecturesPanel.SuspendLayout();
            this.TSders_verListViewGroupbox.SuspendLayout();
            this.TSotherGroupbox.SuspendLayout();
            this.stdControlPanel.SuspendLayout();
            this.stdLecturesPanel.SuspendLayout();
            this.stdLecturesShowGroupbox.SuspendLayout();
            this.stdOldLecturesPanel.SuspendLayout();
            this.stdOldLecturesListviewGroupbox.SuspendLayout();
            this.stdPointsPanel.SuspendLayout();
            this.stdPointListViewGroupbox.SuspendLayout();
            this.stdLecturesAddPanel.SuspendLayout();
            this.stdLectureAddGroupbox.SuspendLayout();
            this.stdProfilePanel.SuspendLayout();
            this.stdProfileİnformationGroupbox.SuspendLayout();
            this.stdControlTransactionGroupbox.SuspendLayout();
            this.periodPanel.SuspendLayout();
            this.PeriodInsertGroupbox.SuspendLayout();
            this.SuspendLayout();
            // 
            // loginPanel
            // 
            this.loginPanel.BackColor = System.Drawing.Color.Transparent;
            this.loginPanel.Controls.Add(this.LogInGroupBox);
            this.loginPanel.Location = new System.Drawing.Point(96, 41);
            this.loginPanel.Name = "loginPanel";
            this.loginPanel.Size = new System.Drawing.Size(909, 517);
            this.loginPanel.TabIndex = 13;
            // 
            // LogInGroupBox
            // 
            this.LogInGroupBox.BackColor = System.Drawing.Color.Transparent;
            this.LogInGroupBox.Controls.Add(this.loginPanelPswPanel);
            this.LogInGroupBox.Controls.Add(this.loginPanelİdPanel);
            this.LogInGroupBox.Controls.Add(this.forgotPswBtn);
            this.LogInGroupBox.Controls.Add(this.STATUpictureBox);
            this.LogInGroupBox.Controls.Add(this.PSWpictureBox);
            this.LogInGroupBox.Controls.Add(this.IDpictureBox);
            this.LogInGroupBox.Controls.Add(this.STATUcomboBox);
            this.LogInGroupBox.Controls.Add(this.PSWtxtbox);
            this.LogInGroupBox.Controls.Add(this.IDtxtbox);
            this.LogInGroupBox.Controls.Add(this.LogInbtn);
            this.LogInGroupBox.ForeColor = System.Drawing.Color.Black;
            this.LogInGroupBox.Location = new System.Drawing.Point(226, 82);
            this.LogInGroupBox.Name = "LogInGroupBox";
            this.LogInGroupBox.Size = new System.Drawing.Size(461, 376);
            this.LogInGroupBox.TabIndex = 9;
            this.LogInGroupBox.TabStop = false;
            this.LogInGroupBox.Text = "GİRİŞ YAP";
            // 
            // loginPanelPswPanel
            // 
            this.loginPanelPswPanel.BackColor = System.Drawing.Color.Black;
            this.loginPanelPswPanel.Location = new System.Drawing.Point(130, 144);
            this.loginPanelPswPanel.Name = "loginPanelPswPanel";
            this.loginPanelPswPanel.Size = new System.Drawing.Size(287, 1);
            this.loginPanelPswPanel.TabIndex = 11;
            // 
            // loginPanelİdPanel
            // 
            this.loginPanelİdPanel.BackColor = System.Drawing.Color.Black;
            this.loginPanelİdPanel.Location = new System.Drawing.Point(130, 76);
            this.loginPanelİdPanel.Name = "loginPanelİdPanel";
            this.loginPanelİdPanel.Size = new System.Drawing.Size(287, 1);
            this.loginPanelİdPanel.TabIndex = 10;
            // 
            // forgotPswBtn
            // 
            this.forgotPswBtn.BackColor = System.Drawing.Color.Transparent;
            this.forgotPswBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.forgotPswBtn.FlatAppearance.BorderSize = 0;
            this.forgotPswBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.forgotPswBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.forgotPswBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.forgotPswBtn.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.forgotPswBtn.ForeColor = System.Drawing.Color.Black;
            this.forgotPswBtn.Location = new System.Drawing.Point(85, 315);
            this.forgotPswBtn.Name = "forgotPswBtn";
            this.forgotPswBtn.Size = new System.Drawing.Size(287, 45);
            this.forgotPswBtn.TabIndex = 4;
            this.forgotPswBtn.Text = "Şifremi Unuttum";
            this.forgotPswBtn.UseVisualStyleBackColor = false;
            this.forgotPswBtn.Click += new System.EventHandler(this.forgotPswBtn_Click);
            // 
            // STATUpictureBox
            // 
            this.STATUpictureBox.BackgroundImage = global::EntityFramework.Properties.Resources.status_bar;
            this.STATUpictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.STATUpictureBox.Location = new System.Drawing.Point(21, 165);
            this.STATUpictureBox.Name = "STATUpictureBox";
            this.STATUpictureBox.Size = new System.Drawing.Size(90, 43);
            this.STATUpictureBox.TabIndex = 11;
            this.STATUpictureBox.TabStop = false;
            // 
            // PSWpictureBox
            // 
            this.PSWpictureBox.BackgroundImage = global::EntityFramework.Properties.Resources.password;
            this.PSWpictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PSWpictureBox.Location = new System.Drawing.Point(21, 101);
            this.PSWpictureBox.Name = "PSWpictureBox";
            this.PSWpictureBox.Size = new System.Drawing.Size(90, 44);
            this.PSWpictureBox.TabIndex = 10;
            this.PSWpictureBox.TabStop = false;
            // 
            // IDpictureBox
            // 
            this.IDpictureBox.BackgroundImage = global::EntityFramework.Properties.Resources.group;
            this.IDpictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.IDpictureBox.Cursor = System.Windows.Forms.Cursors.Default;
            this.IDpictureBox.Location = new System.Drawing.Point(21, 37);
            this.IDpictureBox.Name = "IDpictureBox";
            this.IDpictureBox.Size = new System.Drawing.Size(90, 40);
            this.IDpictureBox.TabIndex = 9;
            this.IDpictureBox.TabStop = false;
            // 
            // STATUcomboBox
            // 
            this.STATUcomboBox.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.STATUcomboBox.FormattingEnabled = true;
            this.STATUcomboBox.Items.AddRange(new object[] {
            "Müdür",
            "Öğretmen",
            "Öğrenci"});
            this.STATUcomboBox.Location = new System.Drawing.Point(130, 184);
            this.STATUcomboBox.Name = "STATUcomboBox";
            this.STATUcomboBox.Size = new System.Drawing.Size(287, 24);
            this.STATUcomboBox.TabIndex = 2;
            // 
            // PSWtxtbox
            // 
            this.PSWtxtbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.PSWtxtbox.Location = new System.Drawing.Point(130, 125);
            this.PSWtxtbox.Name = "PSWtxtbox";
            this.PSWtxtbox.Size = new System.Drawing.Size(287, 15);
            this.PSWtxtbox.TabIndex = 1;
            // 
            // IDtxtbox
            // 
            this.IDtxtbox.BackColor = System.Drawing.Color.White;
            this.IDtxtbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.IDtxtbox.Location = new System.Drawing.Point(130, 57);
            this.IDtxtbox.Name = "IDtxtbox";
            this.IDtxtbox.Size = new System.Drawing.Size(287, 15);
            this.IDtxtbox.TabIndex = 0;
            // 
            // LogInbtn
            // 
            this.LogInbtn.BackColor = System.Drawing.Color.Transparent;
            this.LogInbtn.BackgroundImage = global::EntityFramework.Properties.Resources.enter;
            this.LogInbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.LogInbtn.FlatAppearance.BorderSize = 0;
            this.LogInbtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.LogInbtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.LogInbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LogInbtn.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogInbtn.ForeColor = System.Drawing.Color.Transparent;
            this.LogInbtn.Location = new System.Drawing.Point(130, 240);
            this.LogInbtn.Name = "LogInbtn";
            this.LogInbtn.Size = new System.Drawing.Size(287, 45);
            this.LogInbtn.TabIndex = 3;
            this.LogInbtn.UseVisualStyleBackColor = false;
            this.LogInbtn.Click += new System.EventHandler(this.LogInbtn_Click);
            // 
            // adminPanel
            // 
            this.adminPanel.BackColor = System.Drawing.Color.Transparent;
            this.adminPanel.Controls.Add(this.adminControlPanelGroupbox);
            this.adminPanel.Location = new System.Drawing.Point(96, 41);
            this.adminPanel.Name = "adminPanel";
            this.adminPanel.Size = new System.Drawing.Size(909, 517);
            this.adminPanel.TabIndex = 14;
            // 
            // adminControlPanelGroupbox
            // 
            this.adminControlPanelGroupbox.Controls.Add(this.adminPanelPeriodFinish);
            this.adminControlPanelGroupbox.Controls.Add(this.logOutbtn);
            this.adminControlPanelGroupbox.Controls.Add(this.deletebtn);
            this.adminControlPanelGroupbox.Controls.Add(this.studentAddPanelBtn);
            this.adminControlPanelGroupbox.Controls.Add(this.studentsbtn);
            this.adminControlPanelGroupbox.Controls.Add(this.teachingstaffsbtn);
            this.adminControlPanelGroupbox.Controls.Add(this.teachingstaffaddPanelbtn);
            this.adminControlPanelGroupbox.Location = new System.Drawing.Point(102, 58);
            this.adminControlPanelGroupbox.Name = "adminControlPanelGroupbox";
            this.adminControlPanelGroupbox.Size = new System.Drawing.Size(684, 444);
            this.adminControlPanelGroupbox.TabIndex = 7;
            this.adminControlPanelGroupbox.TabStop = false;
            this.adminControlPanelGroupbox.Text = "İŞLEMLER";
            // 
            // adminPanelPeriodFinish
            // 
            this.adminPanelPeriodFinish.BackColor = System.Drawing.Color.Transparent;
            this.adminPanelPeriodFinish.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.adminPanelPeriodFinish.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.adminPanelPeriodFinish.Location = new System.Drawing.Point(18, 341);
            this.adminPanelPeriodFinish.Name = "adminPanelPeriodFinish";
            this.adminPanelPeriodFinish.Size = new System.Drawing.Size(257, 74);
            this.adminPanelPeriodFinish.TabIndex = 7;
            this.adminPanelPeriodFinish.Text = "Dönem";
            this.adminPanelPeriodFinish.UseVisualStyleBackColor = false;
            this.adminPanelPeriodFinish.Click += new System.EventHandler(this.adminPanelPeriodFinish_Click);
            // 
            // logOutbtn
            // 
            this.logOutbtn.BackColor = System.Drawing.Color.Transparent;
            this.logOutbtn.BackgroundImage = global::EntityFramework.Properties.Resources.enter;
            this.logOutbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.logOutbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.logOutbtn.Location = new System.Drawing.Point(387, 241);
            this.logOutbtn.Name = "logOutbtn";
            this.logOutbtn.Size = new System.Drawing.Size(257, 74);
            this.logOutbtn.TabIndex = 6;
            this.logOutbtn.UseVisualStyleBackColor = false;
            this.logOutbtn.Click += new System.EventHandler(this.logOutbtn_Click);
            // 
            // deletebtn
            // 
            this.deletebtn.BackColor = System.Drawing.Color.Transparent;
            this.deletebtn.BackgroundImage = global::EntityFramework.Properties.Resources.delete;
            this.deletebtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.deletebtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.deletebtn.Location = new System.Drawing.Point(18, 241);
            this.deletebtn.Name = "deletebtn";
            this.deletebtn.Size = new System.Drawing.Size(257, 74);
            this.deletebtn.TabIndex = 5;
            this.deletebtn.UseVisualStyleBackColor = false;
            this.deletebtn.Click += new System.EventHandler(this.deletebtn_Click);
            // 
            // studentAddPanelBtn
            // 
            this.studentAddPanelBtn.BackColor = System.Drawing.Color.Transparent;
            this.studentAddPanelBtn.BackgroundImage = global::EntityFramework.Properties.Resources.student;
            this.studentAddPanelBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.studentAddPanelBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.studentAddPanelBtn.Location = new System.Drawing.Point(18, 141);
            this.studentAddPanelBtn.Name = "studentAddPanelBtn";
            this.studentAddPanelBtn.Size = new System.Drawing.Size(257, 74);
            this.studentAddPanelBtn.TabIndex = 3;
            this.studentAddPanelBtn.UseVisualStyleBackColor = false;
            this.studentAddPanelBtn.Click += new System.EventHandler(this.studentAddPanelBtn_Click);
            // 
            // studentsbtn
            // 
            this.studentsbtn.BackColor = System.Drawing.Color.Transparent;
            this.studentsbtn.BackgroundImage = global::EntityFramework.Properties.Resources.study;
            this.studentsbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.studentsbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.studentsbtn.Location = new System.Drawing.Point(387, 141);
            this.studentsbtn.Name = "studentsbtn";
            this.studentsbtn.Size = new System.Drawing.Size(257, 74);
            this.studentsbtn.TabIndex = 4;
            this.studentsbtn.UseVisualStyleBackColor = false;
            this.studentsbtn.Click += new System.EventHandler(this.studentsbtn_Click);
            // 
            // teachingstaffsbtn
            // 
            this.teachingstaffsbtn.BackColor = System.Drawing.Color.Transparent;
            this.teachingstaffsbtn.BackgroundImage = global::EntityFramework.Properties.Resources.teachers;
            this.teachingstaffsbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.teachingstaffsbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.teachingstaffsbtn.Location = new System.Drawing.Point(387, 41);
            this.teachingstaffsbtn.Name = "teachingstaffsbtn";
            this.teachingstaffsbtn.Size = new System.Drawing.Size(257, 74);
            this.teachingstaffsbtn.TabIndex = 2;
            this.teachingstaffsbtn.UseVisualStyleBackColor = false;
            this.teachingstaffsbtn.Click += new System.EventHandler(this.teachingstaffsbtn_Click);
            // 
            // teachingstaffaddPanelbtn
            // 
            this.teachingstaffaddPanelbtn.BackColor = System.Drawing.Color.Transparent;
            this.teachingstaffaddPanelbtn.BackgroundImage = global::EntityFramework.Properties.Resources._class;
            this.teachingstaffaddPanelbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.teachingstaffaddPanelbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.teachingstaffaddPanelbtn.Location = new System.Drawing.Point(18, 41);
            this.teachingstaffaddPanelbtn.Name = "teachingstaffaddPanelbtn";
            this.teachingstaffaddPanelbtn.Size = new System.Drawing.Size(257, 74);
            this.teachingstaffaddPanelbtn.TabIndex = 1;
            this.teachingstaffaddPanelbtn.UseVisualStyleBackColor = false;
            this.teachingstaffaddPanelbtn.Click += new System.EventHandler(this.teachingstaffaddPanelbtn_Click);
            // 
            // teachingstaffAddpanel
            // 
            this.teachingstaffAddpanel.BackColor = System.Drawing.Color.Transparent;
            this.teachingstaffAddpanel.Controls.Add(this.Teachingstaffaddgroupbox);
            this.teachingstaffAddpanel.Location = new System.Drawing.Point(96, 41);
            this.teachingstaffAddpanel.Name = "teachingstaffAddpanel";
            this.teachingstaffAddpanel.Size = new System.Drawing.Size(909, 517);
            this.teachingstaffAddpanel.TabIndex = 15;
            // 
            // Teachingstaffaddgroupbox
            // 
            this.Teachingstaffaddgroupbox.BackColor = System.Drawing.Color.Transparent;
            this.Teachingstaffaddgroupbox.Controls.Add(this.TSsecurityWordLabel);
            this.Teachingstaffaddgroupbox.Controls.Add(this.TSsecurityWordTextbox);
            this.Teachingstaffaddgroupbox.Controls.Add(this.TSaddPanelBackbtn);
            this.Teachingstaffaddgroupbox.Controls.Add(this.TSaddBTN);
            this.Teachingstaffaddgroupbox.Controls.Add(this.TStc_noLabel);
            this.Teachingstaffaddgroupbox.Controls.Add(this.TSpswlabel);
            this.Teachingstaffaddgroupbox.Controls.Add(this.TSsurnamelabel);
            this.Teachingstaffaddgroupbox.Controls.Add(this.TSnamelabel);
            this.Teachingstaffaddgroupbox.Controls.Add(this.TSprogramsLabel);
            this.Teachingstaffaddgroupbox.Controls.Add(this.TSprogramsCombobox);
            this.Teachingstaffaddgroupbox.Controls.Add(this.TSsurnameTxtbox);
            this.Teachingstaffaddgroupbox.Controls.Add(this.TStc_noTxtbox);
            this.Teachingstaffaddgroupbox.Controls.Add(this.TSpswTxtbox);
            this.Teachingstaffaddgroupbox.Controls.Add(this.TSnameTxtbox);
            this.Teachingstaffaddgroupbox.Location = new System.Drawing.Point(147, 74);
            this.Teachingstaffaddgroupbox.Name = "Teachingstaffaddgroupbox";
            this.Teachingstaffaddgroupbox.Size = new System.Drawing.Size(607, 374);
            this.Teachingstaffaddgroupbox.TabIndex = 14;
            this.Teachingstaffaddgroupbox.TabStop = false;
            this.Teachingstaffaddgroupbox.Text = "Öğretmen Kayıt";
            // 
            // TSsecurityWordLabel
            // 
            this.TSsecurityWordLabel.AutoSize = true;
            this.TSsecurityWordLabel.Location = new System.Drawing.Point(106, 208);
            this.TSsecurityWordLabel.Name = "TSsecurityWordLabel";
            this.TSsecurityWordLabel.Size = new System.Drawing.Size(131, 17);
            this.TSsecurityWordLabel.TabIndex = 12;
            this.TSsecurityWordLabel.Text = "Güvenlik Kelimesi : ";
            // 
            // TSsecurityWordTextbox
            // 
            this.TSsecurityWordTextbox.Location = new System.Drawing.Point(264, 208);
            this.TSsecurityWordTextbox.Name = "TSsecurityWordTextbox";
            this.TSsecurityWordTextbox.Size = new System.Drawing.Size(256, 22);
            this.TSsecurityWordTextbox.TabIndex = 4;
            // 
            // TSaddPanelBackbtn
            // 
            this.TSaddPanelBackbtn.BackColor = System.Drawing.Color.Transparent;
            this.TSaddPanelBackbtn.BackgroundImage = global::EntityFramework.Properties.Resources.left_arrow;
            this.TSaddPanelBackbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.TSaddPanelBackbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.TSaddPanelBackbtn.Location = new System.Drawing.Point(109, 295);
            this.TSaddPanelBackbtn.Name = "TSaddPanelBackbtn";
            this.TSaddPanelBackbtn.Size = new System.Drawing.Size(169, 52);
            this.TSaddPanelBackbtn.TabIndex = 7;
            this.TSaddPanelBackbtn.UseVisualStyleBackColor = false;
            this.TSaddPanelBackbtn.Click += new System.EventHandler(this.TSaddPanelBackbtn_Click);
            // 
            // TSaddBTN
            // 
            this.TSaddBTN.BackColor = System.Drawing.Color.Transparent;
            this.TSaddBTN.BackgroundImage = global::EntityFramework.Properties.Resources.add_user;
            this.TSaddBTN.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.TSaddBTN.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.TSaddBTN.Location = new System.Drawing.Point(351, 295);
            this.TSaddBTN.Name = "TSaddBTN";
            this.TSaddBTN.Size = new System.Drawing.Size(169, 52);
            this.TSaddBTN.TabIndex = 6;
            this.TSaddBTN.UseVisualStyleBackColor = false;
            this.TSaddBTN.Click += new System.EventHandler(this.TSaddBTN_Click);
            // 
            // TStc_noLabel
            // 
            this.TStc_noLabel.AutoSize = true;
            this.TStc_noLabel.Location = new System.Drawing.Point(106, 168);
            this.TStc_noLabel.Name = "TStc_noLabel";
            this.TStc_noLabel.Size = new System.Drawing.Size(100, 17);
            this.TStc_noLabel.TabIndex = 11;
            this.TStc_noLabel.Text = "TC Kimlik No : ";
            // 
            // TSpswlabel
            // 
            this.TSpswlabel.AutoSize = true;
            this.TSpswlabel.Location = new System.Drawing.Point(106, 128);
            this.TSpswlabel.Name = "TSpswlabel";
            this.TSpswlabel.Size = new System.Drawing.Size(49, 17);
            this.TSpswlabel.TabIndex = 10;
            this.TSpswlabel.Text = "Şifre : ";
            // 
            // TSsurnamelabel
            // 
            this.TSsurnamelabel.AutoSize = true;
            this.TSsurnamelabel.Location = new System.Drawing.Point(106, 91);
            this.TSsurnamelabel.Name = "TSsurnamelabel";
            this.TSsurnamelabel.Size = new System.Drawing.Size(64, 17);
            this.TSsurnamelabel.TabIndex = 9;
            this.TSsurnamelabel.Text = "Soyisim :";
            // 
            // TSnamelabel
            // 
            this.TSnamelabel.AutoSize = true;
            this.TSnamelabel.Location = new System.Drawing.Point(106, 47);
            this.TSnamelabel.Name = "TSnamelabel";
            this.TSnamelabel.Size = new System.Drawing.Size(44, 17);
            this.TSnamelabel.TabIndex = 8;
            this.TSnamelabel.Text = "İsim : ";
            // 
            // TSprogramsLabel
            // 
            this.TSprogramsLabel.AutoSize = true;
            this.TSprogramsLabel.Location = new System.Drawing.Point(106, 250);
            this.TSprogramsLabel.Name = "TSprogramsLabel";
            this.TSprogramsLabel.Size = new System.Drawing.Size(59, 17);
            this.TSprogramsLabel.TabIndex = 13;
            this.TSprogramsLabel.Text = "Bölüm : ";
            // 
            // TSprogramsCombobox
            // 
            this.TSprogramsCombobox.FormattingEnabled = true;
            this.TSprogramsCombobox.Location = new System.Drawing.Point(264, 247);
            this.TSprogramsCombobox.Name = "TSprogramsCombobox";
            this.TSprogramsCombobox.Size = new System.Drawing.Size(256, 24);
            this.TSprogramsCombobox.TabIndex = 5;
            // 
            // TSsurnameTxtbox
            // 
            this.TSsurnameTxtbox.Location = new System.Drawing.Point(264, 86);
            this.TSsurnameTxtbox.Name = "TSsurnameTxtbox";
            this.TSsurnameTxtbox.Size = new System.Drawing.Size(256, 22);
            this.TSsurnameTxtbox.TabIndex = 1;
            // 
            // TStc_noTxtbox
            // 
            this.TStc_noTxtbox.Location = new System.Drawing.Point(264, 165);
            this.TStc_noTxtbox.Name = "TStc_noTxtbox";
            this.TStc_noTxtbox.Size = new System.Drawing.Size(256, 22);
            this.TStc_noTxtbox.TabIndex = 3;
            // 
            // TSpswTxtbox
            // 
            this.TSpswTxtbox.Location = new System.Drawing.Point(264, 126);
            this.TSpswTxtbox.Name = "TSpswTxtbox";
            this.TSpswTxtbox.Size = new System.Drawing.Size(256, 22);
            this.TSpswTxtbox.TabIndex = 2;
            // 
            // TSnameTxtbox
            // 
            this.TSnameTxtbox.Location = new System.Drawing.Point(264, 47);
            this.TSnameTxtbox.Name = "TSnameTxtbox";
            this.TSnameTxtbox.Size = new System.Drawing.Size(256, 22);
            this.TSnameTxtbox.TabIndex = 0;
            // 
            // StdaddPanel
            // 
            this.StdaddPanel.BackColor = System.Drawing.Color.Transparent;
            this.StdaddPanel.Controls.Add(this.stdAddGroupbox);
            this.StdaddPanel.Location = new System.Drawing.Point(96, 41);
            this.StdaddPanel.Name = "StdaddPanel";
            this.StdaddPanel.Size = new System.Drawing.Size(909, 517);
            this.StdaddPanel.TabIndex = 7;
            // 
            // stdAddGroupbox
            // 
            this.stdAddGroupbox.BackColor = System.Drawing.Color.Transparent;
            this.stdAddGroupbox.Controls.Add(this.stdSecurityWordLabel);
            this.stdAddGroupbox.Controls.Add(this.stdSecurityWordTextbox);
            this.stdAddGroupbox.Controls.Add(this.stdAddPanelBackBtn);
            this.stdAddGroupbox.Controls.Add(this.stdAddBtn);
            this.stdAddGroupbox.Controls.Add(this.stdProgramsLabel);
            this.stdAddGroupbox.Controls.Add(this.stdPswLabel);
            this.stdAddGroupbox.Controls.Add(this.stdTc_noLabel);
            this.stdAddGroupbox.Controls.Add(this.stdSurnameLabel);
            this.stdAddGroupbox.Controls.Add(this.stdNameLabel);
            this.stdAddGroupbox.Controls.Add(this.stdProgramsCombobox);
            this.stdAddGroupbox.Controls.Add(this.stdPswTxtbox);
            this.stdAddGroupbox.Controls.Add(this.stdSurnameTxtbox);
            this.stdAddGroupbox.Controls.Add(this.stdTc_noTxtbox);
            this.stdAddGroupbox.Controls.Add(this.stdNameTxtbox);
            this.stdAddGroupbox.Location = new System.Drawing.Point(166, 71);
            this.stdAddGroupbox.Name = "stdAddGroupbox";
            this.stdAddGroupbox.Size = new System.Drawing.Size(605, 408);
            this.stdAddGroupbox.TabIndex = 12;
            this.stdAddGroupbox.TabStop = false;
            this.stdAddGroupbox.Text = "Öğrenci Kayıt";
            // 
            // stdSecurityWordLabel
            // 
            this.stdSecurityWordLabel.AutoSize = true;
            this.stdSecurityWordLabel.Location = new System.Drawing.Point(62, 245);
            this.stdSecurityWordLabel.Name = "stdSecurityWordLabel";
            this.stdSecurityWordLabel.Size = new System.Drawing.Size(135, 17);
            this.stdSecurityWordLabel.TabIndex = 10;
            this.stdSecurityWordLabel.Text = "Güvenlik Kelimesi  : ";
            // 
            // stdSecurityWordTextbox
            // 
            this.stdSecurityWordTextbox.Location = new System.Drawing.Point(217, 242);
            this.stdSecurityWordTextbox.Name = "stdSecurityWordTextbox";
            this.stdSecurityWordTextbox.Size = new System.Drawing.Size(284, 22);
            this.stdSecurityWordTextbox.TabIndex = 4;
            // 
            // stdAddPanelBackBtn
            // 
            this.stdAddPanelBackBtn.BackgroundImage = global::EntityFramework.Properties.Resources.left_arrow;
            this.stdAddPanelBackBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.stdAddPanelBackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.stdAddPanelBackBtn.Location = new System.Drawing.Point(127, 337);
            this.stdAddPanelBackBtn.Name = "stdAddPanelBackBtn";
            this.stdAddPanelBackBtn.Size = new System.Drawing.Size(173, 47);
            this.stdAddPanelBackBtn.TabIndex = 13;
            this.stdAddPanelBackBtn.UseVisualStyleBackColor = true;
            this.stdAddPanelBackBtn.Click += new System.EventHandler(this.stdAddPanelBackBtn_Click);
            // 
            // stdAddBtn
            // 
            this.stdAddBtn.BackColor = System.Drawing.Color.Transparent;
            this.stdAddBtn.BackgroundImage = global::EntityFramework.Properties.Resources.add_user;
            this.stdAddBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.stdAddBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.stdAddBtn.Location = new System.Drawing.Point(328, 337);
            this.stdAddBtn.Name = "stdAddBtn";
            this.stdAddBtn.Size = new System.Drawing.Size(173, 47);
            this.stdAddBtn.TabIndex = 12;
            this.stdAddBtn.UseVisualStyleBackColor = false;
            this.stdAddBtn.Click += new System.EventHandler(this.stdAddBtn_Click);
            // 
            // stdProgramsLabel
            // 
            this.stdProgramsLabel.AutoSize = true;
            this.stdProgramsLabel.Location = new System.Drawing.Point(62, 287);
            this.stdProgramsLabel.Name = "stdProgramsLabel";
            this.stdProgramsLabel.Size = new System.Drawing.Size(59, 17);
            this.stdProgramsLabel.TabIndex = 11;
            this.stdProgramsLabel.Text = "Bölüm : ";
            // 
            // stdPswLabel
            // 
            this.stdPswLabel.AutoSize = true;
            this.stdPswLabel.Location = new System.Drawing.Point(65, 198);
            this.stdPswLabel.Name = "stdPswLabel";
            this.stdPswLabel.Size = new System.Drawing.Size(49, 17);
            this.stdPswLabel.TabIndex = 9;
            this.stdPswLabel.Text = "Şifre : ";
            // 
            // stdTc_noLabel
            // 
            this.stdTc_noLabel.AutoSize = true;
            this.stdTc_noLabel.Location = new System.Drawing.Point(62, 148);
            this.stdTc_noLabel.Name = "stdTc_noLabel";
            this.stdTc_noLabel.Size = new System.Drawing.Size(100, 17);
            this.stdTc_noLabel.TabIndex = 8;
            this.stdTc_noLabel.Text = "TC Kimlik No : ";
            // 
            // stdSurnameLabel
            // 
            this.stdSurnameLabel.AutoSize = true;
            this.stdSurnameLabel.Location = new System.Drawing.Point(63, 102);
            this.stdSurnameLabel.Name = "stdSurnameLabel";
            this.stdSurnameLabel.Size = new System.Drawing.Size(68, 17);
            this.stdSurnameLabel.TabIndex = 7;
            this.stdSurnameLabel.Text = "Soyisim : ";
            // 
            // stdNameLabel
            // 
            this.stdNameLabel.AutoSize = true;
            this.stdNameLabel.Location = new System.Drawing.Point(63, 54);
            this.stdNameLabel.Name = "stdNameLabel";
            this.stdNameLabel.Size = new System.Drawing.Size(44, 17);
            this.stdNameLabel.TabIndex = 6;
            this.stdNameLabel.Text = "İsim : ";
            // 
            // stdProgramsCombobox
            // 
            this.stdProgramsCombobox.FormattingEnabled = true;
            this.stdProgramsCombobox.Location = new System.Drawing.Point(217, 285);
            this.stdProgramsCombobox.Name = "stdProgramsCombobox";
            this.stdProgramsCombobox.Size = new System.Drawing.Size(284, 24);
            this.stdProgramsCombobox.TabIndex = 5;
            // 
            // stdPswTxtbox
            // 
            this.stdPswTxtbox.Location = new System.Drawing.Point(217, 193);
            this.stdPswTxtbox.Name = "stdPswTxtbox";
            this.stdPswTxtbox.Size = new System.Drawing.Size(284, 22);
            this.stdPswTxtbox.TabIndex = 3;
            // 
            // stdSurnameTxtbox
            // 
            this.stdSurnameTxtbox.Location = new System.Drawing.Point(217, 97);
            this.stdSurnameTxtbox.Name = "stdSurnameTxtbox";
            this.stdSurnameTxtbox.Size = new System.Drawing.Size(284, 22);
            this.stdSurnameTxtbox.TabIndex = 1;
            // 
            // stdTc_noTxtbox
            // 
            this.stdTc_noTxtbox.Location = new System.Drawing.Point(217, 148);
            this.stdTc_noTxtbox.Name = "stdTc_noTxtbox";
            this.stdTc_noTxtbox.Size = new System.Drawing.Size(284, 22);
            this.stdTc_noTxtbox.TabIndex = 2;
            // 
            // stdNameTxtbox
            // 
            this.stdNameTxtbox.Location = new System.Drawing.Point(217, 49);
            this.stdNameTxtbox.Name = "stdNameTxtbox";
            this.stdNameTxtbox.Size = new System.Drawing.Size(284, 22);
            this.stdNameTxtbox.TabIndex = 0;
            // 
            // dellPanel
            // 
            this.dellPanel.BackColor = System.Drawing.Color.Transparent;
            this.dellPanel.Controls.Add(this.dellGroupbox);
            this.dellPanel.Location = new System.Drawing.Point(96, 41);
            this.dellPanel.Name = "dellPanel";
            this.dellPanel.Size = new System.Drawing.Size(909, 517);
            this.dellPanel.TabIndex = 10;
            // 
            // dellGroupbox
            // 
            this.dellGroupbox.BackColor = System.Drawing.Color.Transparent;
            this.dellGroupbox.Controls.Add(this.dellDatagridView);
            this.dellGroupbox.Controls.Add(this.dellInputGroupbox);
            this.dellGroupbox.Location = new System.Drawing.Point(65, 29);
            this.dellGroupbox.Name = "dellGroupbox";
            this.dellGroupbox.Size = new System.Drawing.Size(784, 466);
            this.dellGroupbox.TabIndex = 6;
            this.dellGroupbox.TabStop = false;
            this.dellGroupbox.Text = "KULLANICI SİL";
            // 
            // dellDatagridView
            // 
            this.dellDatagridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dellDatagridView.Location = new System.Drawing.Point(72, 56);
            this.dellDatagridView.Name = "dellDatagridView";
            this.dellDatagridView.RowHeadersWidth = 51;
            this.dellDatagridView.RowTemplate.Height = 24;
            this.dellDatagridView.Size = new System.Drawing.Size(628, 202);
            this.dellDatagridView.TabIndex = 7;
            this.dellDatagridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dellDatagridView_CellClick);
            // 
            // dellInputGroupbox
            // 
            this.dellInputGroupbox.Controls.Add(this.dellPanelBackBtn);
            this.dellInputGroupbox.Controls.Add(this.dellBtn);
            this.dellInputGroupbox.Controls.Add(this.dellIdLabel);
            this.dellInputGroupbox.Controls.Add(this.dellStatuLabel);
            this.dellInputGroupbox.Controls.Add(this.dellIdTxtbox);
            this.dellInputGroupbox.Controls.Add(this.dellStatuCombobox);
            this.dellInputGroupbox.Location = new System.Drawing.Point(72, 287);
            this.dellInputGroupbox.Name = "dellInputGroupbox";
            this.dellInputGroupbox.Size = new System.Drawing.Size(629, 171);
            this.dellInputGroupbox.TabIndex = 6;
            this.dellInputGroupbox.TabStop = false;
            this.dellInputGroupbox.Text = "Bilgiler";
            // 
            // dellPanelBackBtn
            // 
            this.dellPanelBackBtn.BackColor = System.Drawing.Color.Transparent;
            this.dellPanelBackBtn.BackgroundImage = global::EntityFramework.Properties.Resources.left_arrow;
            this.dellPanelBackBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.dellPanelBackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.dellPanelBackBtn.Location = new System.Drawing.Point(32, 117);
            this.dellPanelBackBtn.Name = "dellPanelBackBtn";
            this.dellPanelBackBtn.Size = new System.Drawing.Size(242, 46);
            this.dellPanelBackBtn.TabIndex = 5;
            this.dellPanelBackBtn.UseVisualStyleBackColor = false;
            this.dellPanelBackBtn.Click += new System.EventHandler(this.dellPanelBackBtn_Click);
            // 
            // dellBtn
            // 
            this.dellBtn.BackColor = System.Drawing.Color.Transparent;
            this.dellBtn.BackgroundImage = global::EntityFramework.Properties.Resources.delete;
            this.dellBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.dellBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.dellBtn.Location = new System.Drawing.Point(319, 118);
            this.dellBtn.Name = "dellBtn";
            this.dellBtn.Size = new System.Drawing.Size(242, 46);
            this.dellBtn.TabIndex = 4;
            this.dellBtn.UseVisualStyleBackColor = false;
            this.dellBtn.Click += new System.EventHandler(this.dellBtn_Click);
            // 
            // dellIdLabel
            // 
            this.dellIdLabel.AutoSize = true;
            this.dellIdLabel.Location = new System.Drawing.Point(38, 81);
            this.dellIdLabel.Name = "dellIdLabel";
            this.dellIdLabel.Size = new System.Drawing.Size(31, 17);
            this.dellIdLabel.TabIndex = 3;
            this.dellIdLabel.Text = "İd : ";
            // 
            // dellStatuLabel
            // 
            this.dellStatuLabel.AutoSize = true;
            this.dellStatuLabel.Location = new System.Drawing.Point(38, 50);
            this.dellStatuLabel.Name = "dellStatuLabel";
            this.dellStatuLabel.Size = new System.Drawing.Size(53, 17);
            this.dellStatuLabel.TabIndex = 2;
            this.dellStatuLabel.Text = "Statü : ";
            // 
            // dellIdTxtbox
            // 
            this.dellIdTxtbox.Location = new System.Drawing.Point(150, 82);
            this.dellIdTxtbox.Name = "dellIdTxtbox";
            this.dellIdTxtbox.Size = new System.Drawing.Size(411, 22);
            this.dellIdTxtbox.TabIndex = 1;
            // 
            // dellStatuCombobox
            // 
            this.dellStatuCombobox.FormattingEnabled = true;
            this.dellStatuCombobox.Items.AddRange(new object[] {
            "Öğrenci",
            "Öğretmen"});
            this.dellStatuCombobox.Location = new System.Drawing.Point(149, 43);
            this.dellStatuCombobox.Name = "dellStatuCombobox";
            this.dellStatuCombobox.Size = new System.Drawing.Size(412, 24);
            this.dellStatuCombobox.TabIndex = 0;
            this.dellStatuCombobox.SelectedIndexChanged += new System.EventHandler(this.dellStatuCombobox_SelectedIndexChanged);
            // 
            // TSgridViewPanel
            // 
            this.TSgridViewPanel.BackColor = System.Drawing.Color.Transparent;
            this.TSgridViewPanel.Controls.Add(this.TSgridViewUpdateGroupbox);
            this.TSgridViewPanel.Controls.Add(this.TSsearchGroupbox);
            this.TSgridViewPanel.Controls.Add(this.TSgridViewGroupbox);
            this.TSgridViewPanel.Location = new System.Drawing.Point(96, 41);
            this.TSgridViewPanel.Name = "TSgridViewPanel";
            this.TSgridViewPanel.Size = new System.Drawing.Size(909, 517);
            this.TSgridViewPanel.TabIndex = 7;
            // 
            // TSgridViewUpdateGroupbox
            // 
            this.TSgridViewUpdateGroupbox.Controls.Add(this.TSgridViewUpdateBtn);
            this.TSgridViewUpdateGroupbox.Controls.Add(this.TSgridViewBackBtn);
            this.TSgridViewUpdateGroupbox.Controls.Add(this.TSgridViewUpdateTcNoLabel);
            this.TSgridViewUpdateGroupbox.Controls.Add(this.TSgridViewUpdateSurnameLabel);
            this.TSgridViewUpdateGroupbox.Controls.Add(this.TSgridViewUpdateNameLabel);
            this.TSgridViewUpdateGroupbox.Controls.Add(this.TSgridViewUpdateTCNoTextbox);
            this.TSgridViewUpdateGroupbox.Controls.Add(this.TSgridViewUpdateNameTextbox);
            this.TSgridViewUpdateGroupbox.Controls.Add(this.TSgridViewUpdateSurnameTextbox);
            this.TSgridViewUpdateGroupbox.Location = new System.Drawing.Point(69, 374);
            this.TSgridViewUpdateGroupbox.Name = "TSgridViewUpdateGroupbox";
            this.TSgridViewUpdateGroupbox.Size = new System.Drawing.Size(751, 128);
            this.TSgridViewUpdateGroupbox.TabIndex = 5;
            this.TSgridViewUpdateGroupbox.TabStop = false;
            this.TSgridViewUpdateGroupbox.Text = "GÜNCELLEME";
            // 
            // TSgridViewUpdateBtn
            // 
            this.TSgridViewUpdateBtn.BackColor = System.Drawing.Color.Transparent;
            this.TSgridViewUpdateBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.TSgridViewUpdateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.TSgridViewUpdateBtn.Location = new System.Drawing.Point(581, 25);
            this.TSgridViewUpdateBtn.Name = "TSgridViewUpdateBtn";
            this.TSgridViewUpdateBtn.Size = new System.Drawing.Size(155, 45);
            this.TSgridViewUpdateBtn.TabIndex = 7;
            this.TSgridViewUpdateBtn.Text = "GÜNCELLE";
            this.TSgridViewUpdateBtn.UseVisualStyleBackColor = false;
            this.TSgridViewUpdateBtn.Click += new System.EventHandler(this.TSgridViewUpdateBtn_Click);
            // 
            // TSgridViewBackBtn
            // 
            this.TSgridViewBackBtn.BackColor = System.Drawing.Color.Transparent;
            this.TSgridViewBackBtn.BackgroundImage = global::EntityFramework.Properties.Resources.left_arrow;
            this.TSgridViewBackBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.TSgridViewBackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.TSgridViewBackBtn.Location = new System.Drawing.Point(581, 75);
            this.TSgridViewBackBtn.Name = "TSgridViewBackBtn";
            this.TSgridViewBackBtn.Size = new System.Drawing.Size(155, 45);
            this.TSgridViewBackBtn.TabIndex = 6;
            this.TSgridViewBackBtn.UseVisualStyleBackColor = false;
            this.TSgridViewBackBtn.Click += new System.EventHandler(this.TSgridViewBackBtn_Click);
            // 
            // TSgridViewUpdateTcNoLabel
            // 
            this.TSgridViewUpdateTcNoLabel.AutoSize = true;
            this.TSgridViewUpdateTcNoLabel.Location = new System.Drawing.Point(293, 30);
            this.TSgridViewUpdateTcNoLabel.Name = "TSgridViewUpdateTcNoLabel";
            this.TSgridViewUpdateTcNoLabel.Size = new System.Drawing.Size(100, 17);
            this.TSgridViewUpdateTcNoLabel.TabIndex = 5;
            this.TSgridViewUpdateTcNoLabel.Text = "TC Kimlik No : ";
            // 
            // TSgridViewUpdateSurnameLabel
            // 
            this.TSgridViewUpdateSurnameLabel.AutoSize = true;
            this.TSgridViewUpdateSurnameLabel.Location = new System.Drawing.Point(37, 72);
            this.TSgridViewUpdateSurnameLabel.Name = "TSgridViewUpdateSurnameLabel";
            this.TSgridViewUpdateSurnameLabel.Size = new System.Drawing.Size(68, 17);
            this.TSgridViewUpdateSurnameLabel.TabIndex = 4;
            this.TSgridViewUpdateSurnameLabel.Text = "Soyisim : ";
            // 
            // TSgridViewUpdateNameLabel
            // 
            this.TSgridViewUpdateNameLabel.AutoSize = true;
            this.TSgridViewUpdateNameLabel.Location = new System.Drawing.Point(37, 30);
            this.TSgridViewUpdateNameLabel.Name = "TSgridViewUpdateNameLabel";
            this.TSgridViewUpdateNameLabel.Size = new System.Drawing.Size(44, 17);
            this.TSgridViewUpdateNameLabel.TabIndex = 3;
            this.TSgridViewUpdateNameLabel.Text = "İsim : ";
            // 
            // TSgridViewUpdateTCNoTextbox
            // 
            this.TSgridViewUpdateTCNoTextbox.Location = new System.Drawing.Point(411, 30);
            this.TSgridViewUpdateTCNoTextbox.Name = "TSgridViewUpdateTCNoTextbox";
            this.TSgridViewUpdateTCNoTextbox.Size = new System.Drawing.Size(155, 22);
            this.TSgridViewUpdateTCNoTextbox.TabIndex = 4;
            // 
            // TSgridViewUpdateNameTextbox
            // 
            this.TSgridViewUpdateNameTextbox.Location = new System.Drawing.Point(113, 30);
            this.TSgridViewUpdateNameTextbox.Name = "TSgridViewUpdateNameTextbox";
            this.TSgridViewUpdateNameTextbox.Size = new System.Drawing.Size(155, 22);
            this.TSgridViewUpdateNameTextbox.TabIndex = 2;
            // 
            // TSgridViewUpdateSurnameTextbox
            // 
            this.TSgridViewUpdateSurnameTextbox.Location = new System.Drawing.Point(113, 72);
            this.TSgridViewUpdateSurnameTextbox.Name = "TSgridViewUpdateSurnameTextbox";
            this.TSgridViewUpdateSurnameTextbox.Size = new System.Drawing.Size(155, 22);
            this.TSgridViewUpdateSurnameTextbox.TabIndex = 3;
            // 
            // TSsearchGroupbox
            // 
            this.TSsearchGroupbox.BackColor = System.Drawing.Color.Transparent;
            this.TSsearchGroupbox.Controls.Add(this.TSgridViewSearchbtn);
            this.TSsearchGroupbox.Controls.Add(this.TSgridViewSearchLabel);
            this.TSsearchGroupbox.Controls.Add(this.TSgridViewSearchTxtbox);
            this.TSsearchGroupbox.Location = new System.Drawing.Point(69, 288);
            this.TSsearchGroupbox.Name = "TSsearchGroupbox";
            this.TSsearchGroupbox.Size = new System.Drawing.Size(751, 81);
            this.TSsearchGroupbox.TabIndex = 4;
            this.TSsearchGroupbox.TabStop = false;
            this.TSsearchGroupbox.Text = "ARAMA";
            // 
            // TSgridViewSearchbtn
            // 
            this.TSgridViewSearchbtn.BackColor = System.Drawing.Color.Transparent;
            this.TSgridViewSearchbtn.BackgroundImage = global::EntityFramework.Properties.Resources.magnifying_glass;
            this.TSgridViewSearchbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.TSgridViewSearchbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.TSgridViewSearchbtn.Location = new System.Drawing.Point(520, 27);
            this.TSgridViewSearchbtn.Name = "TSgridViewSearchbtn";
            this.TSgridViewSearchbtn.Size = new System.Drawing.Size(155, 45);
            this.TSgridViewSearchbtn.TabIndex = 1;
            this.TSgridViewSearchbtn.UseVisualStyleBackColor = false;
            this.TSgridViewSearchbtn.Click += new System.EventHandler(this.TSgridViewSearchbtn_Click);
            // 
            // TSgridViewSearchLabel
            // 
            this.TSgridViewSearchLabel.AutoSize = true;
            this.TSgridViewSearchLabel.Location = new System.Drawing.Point(38, 41);
            this.TSgridViewSearchLabel.Name = "TSgridViewSearchLabel";
            this.TSgridViewSearchLabel.Size = new System.Drawing.Size(44, 17);
            this.TSgridViewSearchLabel.TabIndex = 2;
            this.TSgridViewSearchLabel.Text = "İsim : ";
            // 
            // TSgridViewSearchTxtbox
            // 
            this.TSgridViewSearchTxtbox.Location = new System.Drawing.Point(125, 42);
            this.TSgridViewSearchTxtbox.Name = "TSgridViewSearchTxtbox";
            this.TSgridViewSearchTxtbox.Size = new System.Drawing.Size(376, 22);
            this.TSgridViewSearchTxtbox.TabIndex = 0;
            // 
            // TSgridViewGroupbox
            // 
            this.TSgridViewGroupbox.BackColor = System.Drawing.Color.Transparent;
            this.TSgridViewGroupbox.Controls.Add(this.TSgridView);
            this.TSgridViewGroupbox.Location = new System.Drawing.Point(69, 17);
            this.TSgridViewGroupbox.Name = "TSgridViewGroupbox";
            this.TSgridViewGroupbox.Size = new System.Drawing.Size(751, 263);
            this.TSgridViewGroupbox.TabIndex = 0;
            this.TSgridViewGroupbox.TabStop = false;
            this.TSgridViewGroupbox.Text = "ÖĞRETMENLER";
            // 
            // TSgridView
            // 
            this.TSgridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TSgridView.Location = new System.Drawing.Point(75, 20);
            this.TSgridView.Name = "TSgridView";
            this.TSgridView.RowHeadersWidth = 51;
            this.TSgridView.RowTemplate.Height = 24;
            this.TSgridView.Size = new System.Drawing.Size(600, 224);
            this.TSgridView.TabIndex = 0;
            this.TSgridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.TSgridView_CellClick);
            // 
            // stdGridViewPanel
            // 
            this.stdGridViewPanel.BackColor = System.Drawing.Color.Transparent;
            this.stdGridViewPanel.Controls.Add(this.stdGridviewUpdateGroupbox);
            this.stdGridViewPanel.Controls.Add(this.stdGridViewSearchGroupbox);
            this.stdGridViewPanel.Controls.Add(this.stdGridViewGroupbox);
            this.stdGridViewPanel.Location = new System.Drawing.Point(96, 41);
            this.stdGridViewPanel.Name = "stdGridViewPanel";
            this.stdGridViewPanel.Size = new System.Drawing.Size(909, 517);
            this.stdGridViewPanel.TabIndex = 10;
            // 
            // stdGridviewUpdateGroupbox
            // 
            this.stdGridviewUpdateGroupbox.Controls.Add(this.stdGridViewUpdateBtn);
            this.stdGridviewUpdateGroupbox.Controls.Add(this.stdGridViewBackBtn);
            this.stdGridviewUpdateGroupbox.Controls.Add(this.stdGridViewUpdateTCNoLabel);
            this.stdGridviewUpdateGroupbox.Controls.Add(this.stdGridViewUpdateSurnameLabel);
            this.stdGridviewUpdateGroupbox.Controls.Add(this.stdGridViewUpdateNameLabel);
            this.stdGridviewUpdateGroupbox.Controls.Add(this.stdGridViewUpdateTCNoTextbox);
            this.stdGridviewUpdateGroupbox.Controls.Add(this.stdGridViewUpdateNameTextbox);
            this.stdGridviewUpdateGroupbox.Controls.Add(this.stdGridViewUpdateSurnameTextbox);
            this.stdGridviewUpdateGroupbox.Location = new System.Drawing.Point(69, 371);
            this.stdGridviewUpdateGroupbox.Name = "stdGridviewUpdateGroupbox";
            this.stdGridviewUpdateGroupbox.Size = new System.Drawing.Size(751, 139);
            this.stdGridviewUpdateGroupbox.TabIndex = 5;
            this.stdGridviewUpdateGroupbox.TabStop = false;
            this.stdGridviewUpdateGroupbox.Text = "GÜNCELLE";
            // 
            // stdGridViewUpdateBtn
            // 
            this.stdGridViewUpdateBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.stdGridViewUpdateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.stdGridViewUpdateBtn.Location = new System.Drawing.Point(581, 30);
            this.stdGridViewUpdateBtn.Name = "stdGridViewUpdateBtn";
            this.stdGridViewUpdateBtn.Size = new System.Drawing.Size(155, 45);
            this.stdGridViewUpdateBtn.TabIndex = 4;
            this.stdGridViewUpdateBtn.Text = "GÜNCELLE";
            this.stdGridViewUpdateBtn.UseVisualStyleBackColor = true;
            this.stdGridViewUpdateBtn.Click += new System.EventHandler(this.stdGridViewUpdateBtn_Click);
            // 
            // stdGridViewBackBtn
            // 
            this.stdGridViewBackBtn.BackColor = System.Drawing.Color.Transparent;
            this.stdGridViewBackBtn.BackgroundImage = global::EntityFramework.Properties.Resources.left_arrow;
            this.stdGridViewBackBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.stdGridViewBackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.stdGridViewBackBtn.Location = new System.Drawing.Point(581, 86);
            this.stdGridViewBackBtn.Name = "stdGridViewBackBtn";
            this.stdGridViewBackBtn.Size = new System.Drawing.Size(155, 45);
            this.stdGridViewBackBtn.TabIndex = 4;
            this.stdGridViewBackBtn.UseVisualStyleBackColor = false;
            this.stdGridViewBackBtn.Click += new System.EventHandler(this.stdGridViewBackBtn_Click);
            // 
            // stdGridViewUpdateTCNoLabel
            // 
            this.stdGridViewUpdateTCNoLabel.AutoSize = true;
            this.stdGridViewUpdateTCNoLabel.Location = new System.Drawing.Point(293, 30);
            this.stdGridViewUpdateTCNoLabel.Name = "stdGridViewUpdateTCNoLabel";
            this.stdGridViewUpdateTCNoLabel.Size = new System.Drawing.Size(96, 17);
            this.stdGridViewUpdateTCNoLabel.TabIndex = 5;
            this.stdGridViewUpdateTCNoLabel.Text = "TC Kimlik No :";
            // 
            // stdGridViewUpdateSurnameLabel
            // 
            this.stdGridViewUpdateSurnameLabel.AutoSize = true;
            this.stdGridViewUpdateSurnameLabel.Location = new System.Drawing.Point(44, 73);
            this.stdGridViewUpdateSurnameLabel.Name = "stdGridViewUpdateSurnameLabel";
            this.stdGridViewUpdateSurnameLabel.Size = new System.Drawing.Size(64, 17);
            this.stdGridViewUpdateSurnameLabel.TabIndex = 4;
            this.stdGridViewUpdateSurnameLabel.Text = "Soyisim :";
            // 
            // stdGridViewUpdateNameLabel
            // 
            this.stdGridViewUpdateNameLabel.AutoSize = true;
            this.stdGridViewUpdateNameLabel.Location = new System.Drawing.Point(44, 30);
            this.stdGridViewUpdateNameLabel.Name = "stdGridViewUpdateNameLabel";
            this.stdGridViewUpdateNameLabel.Size = new System.Drawing.Size(44, 17);
            this.stdGridViewUpdateNameLabel.TabIndex = 3;
            this.stdGridViewUpdateNameLabel.Text = "İsim : ";
            // 
            // stdGridViewUpdateTCNoTextbox
            // 
            this.stdGridViewUpdateTCNoTextbox.Location = new System.Drawing.Point(403, 30);
            this.stdGridViewUpdateTCNoTextbox.Name = "stdGridViewUpdateTCNoTextbox";
            this.stdGridViewUpdateTCNoTextbox.Size = new System.Drawing.Size(155, 22);
            this.stdGridViewUpdateTCNoTextbox.TabIndex = 2;
            // 
            // stdGridViewUpdateNameTextbox
            // 
            this.stdGridViewUpdateNameTextbox.Location = new System.Drawing.Point(123, 30);
            this.stdGridViewUpdateNameTextbox.Name = "stdGridViewUpdateNameTextbox";
            this.stdGridViewUpdateNameTextbox.Size = new System.Drawing.Size(155, 22);
            this.stdGridViewUpdateNameTextbox.TabIndex = 1;
            // 
            // stdGridViewUpdateSurnameTextbox
            // 
            this.stdGridViewUpdateSurnameTextbox.Location = new System.Drawing.Point(123, 70);
            this.stdGridViewUpdateSurnameTextbox.Name = "stdGridViewUpdateSurnameTextbox";
            this.stdGridViewUpdateSurnameTextbox.Size = new System.Drawing.Size(155, 22);
            this.stdGridViewUpdateSurnameTextbox.TabIndex = 0;
            // 
            // stdGridViewSearchGroupbox
            // 
            this.stdGridViewSearchGroupbox.BackColor = System.Drawing.Color.Transparent;
            this.stdGridViewSearchGroupbox.Controls.Add(this.stdGridViewSearchBtn);
            this.stdGridViewSearchGroupbox.Controls.Add(this.stdGridViewSearcLabel);
            this.stdGridViewSearchGroupbox.Controls.Add(this.stdGridViewSearchTxtbox);
            this.stdGridViewSearchGroupbox.Location = new System.Drawing.Point(69, 287);
            this.stdGridViewSearchGroupbox.Name = "stdGridViewSearchGroupbox";
            this.stdGridViewSearchGroupbox.Size = new System.Drawing.Size(751, 81);
            this.stdGridViewSearchGroupbox.TabIndex = 4;
            this.stdGridViewSearchGroupbox.TabStop = false;
            this.stdGridViewSearchGroupbox.Text = "ARAMA";
            // 
            // stdGridViewSearchBtn
            // 
            this.stdGridViewSearchBtn.BackgroundImage = global::EntityFramework.Properties.Resources.magnifying_glass;
            this.stdGridViewSearchBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.stdGridViewSearchBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.stdGridViewSearchBtn.Location = new System.Drawing.Point(520, 27);
            this.stdGridViewSearchBtn.Name = "stdGridViewSearchBtn";
            this.stdGridViewSearchBtn.Size = new System.Drawing.Size(155, 45);
            this.stdGridViewSearchBtn.TabIndex = 3;
            this.stdGridViewSearchBtn.UseVisualStyleBackColor = true;
            this.stdGridViewSearchBtn.Click += new System.EventHandler(this.stdGridViewSearchBtn_Click);
            // 
            // stdGridViewSearcLabel
            // 
            this.stdGridViewSearcLabel.AutoSize = true;
            this.stdGridViewSearcLabel.Location = new System.Drawing.Point(38, 41);
            this.stdGridViewSearcLabel.Name = "stdGridViewSearcLabel";
            this.stdGridViewSearcLabel.Size = new System.Drawing.Size(44, 17);
            this.stdGridViewSearcLabel.TabIndex = 2;
            this.stdGridViewSearcLabel.Text = "İsim : ";
            // 
            // stdGridViewSearchTxtbox
            // 
            this.stdGridViewSearchTxtbox.Location = new System.Drawing.Point(125, 42);
            this.stdGridViewSearchTxtbox.Name = "stdGridViewSearchTxtbox";
            this.stdGridViewSearchTxtbox.Size = new System.Drawing.Size(376, 22);
            this.stdGridViewSearchTxtbox.TabIndex = 1;
            // 
            // stdGridViewGroupbox
            // 
            this.stdGridViewGroupbox.BackColor = System.Drawing.Color.Transparent;
            this.stdGridViewGroupbox.Controls.Add(this.stdDataGridView);
            this.stdGridViewGroupbox.Location = new System.Drawing.Point(69, 8);
            this.stdGridViewGroupbox.Name = "stdGridViewGroupbox";
            this.stdGridViewGroupbox.Size = new System.Drawing.Size(751, 267);
            this.stdGridViewGroupbox.TabIndex = 0;
            this.stdGridViewGroupbox.TabStop = false;
            this.stdGridViewGroupbox.Text = "ÖĞRENCİLER";
            // 
            // stdDataGridView
            // 
            this.stdDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.stdDataGridView.Location = new System.Drawing.Point(63, 21);
            this.stdDataGridView.Name = "stdDataGridView";
            this.stdDataGridView.RowHeadersWidth = 51;
            this.stdDataGridView.RowTemplate.Height = 24;
            this.stdDataGridView.Size = new System.Drawing.Size(623, 222);
            this.stdDataGridView.TabIndex = 0;
            this.stdDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.stdDataGridView_CellClick);
            // 
            // TScontrolPanel
            // 
            this.TScontrolPanel.BackColor = System.Drawing.Color.Transparent;
            this.TScontrolPanel.Controls.Add(this.TScontrolGroupbox);
            this.TScontrolPanel.Location = new System.Drawing.Point(96, 41);
            this.TScontrolPanel.Name = "TScontrolPanel";
            this.TScontrolPanel.Size = new System.Drawing.Size(909, 517);
            this.TScontrolPanel.TabIndex = 16;
            // 
            // TScontrolGroupbox
            // 
            this.TScontrolGroupbox.BackColor = System.Drawing.Color.Transparent;
            this.TScontrolGroupbox.Controls.Add(this.TSlecturesPanel);
            this.TScontrolGroupbox.Controls.Add(this.TSpointsPanel);
            this.TScontrolGroupbox.Controls.Add(this.TSProfilePanel);
            this.TScontrolGroupbox.Controls.Add(this.TSAddLecturesPanel);
            this.TScontrolGroupbox.Controls.Add(this.TSotherGroupbox);
            this.TScontrolGroupbox.Location = new System.Drawing.Point(12, 21);
            this.TScontrolGroupbox.Name = "TScontrolGroupbox";
            this.TScontrolGroupbox.Size = new System.Drawing.Size(887, 480);
            this.TScontrolGroupbox.TabIndex = 0;
            this.TScontrolGroupbox.TabStop = false;
            this.TScontrolGroupbox.Text = "Öğretmen Panel";
            // 
            // TSlecturesPanel
            // 
            this.TSlecturesPanel.BackColor = System.Drawing.Color.Transparent;
            this.TSlecturesPanel.Controls.Add(this.TSlecturesGroupbox);
            this.TSlecturesPanel.Location = new System.Drawing.Point(284, 21);
            this.TSlecturesPanel.Name = "TSlecturesPanel";
            this.TSlecturesPanel.Size = new System.Drawing.Size(586, 433);
            this.TSlecturesPanel.TabIndex = 8;
            // 
            // TSlecturesGroupbox
            // 
            this.TSlecturesGroupbox.BackColor = System.Drawing.Color.Transparent;
            this.TSlecturesGroupbox.Controls.Add(this.TSLecturesListView);
            this.TSlecturesGroupbox.Location = new System.Drawing.Point(24, 36);
            this.TSlecturesGroupbox.Name = "TSlecturesGroupbox";
            this.TSlecturesGroupbox.Size = new System.Drawing.Size(541, 332);
            this.TSlecturesGroupbox.TabIndex = 6;
            this.TSlecturesGroupbox.TabStop = false;
            this.TSlecturesGroupbox.Text = "DERSLERİM";
            // 
            // TSLecturesListView
            // 
            this.TSLecturesListView.HideSelection = false;
            this.TSLecturesListView.Location = new System.Drawing.Point(15, 50);
            this.TSLecturesListView.Name = "TSLecturesListView";
            this.TSLecturesListView.Size = new System.Drawing.Size(509, 215);
            this.TSLecturesListView.TabIndex = 2;
            this.TSLecturesListView.UseCompatibleStateImageBehavior = false;
            // 
            // TSpointsPanel
            // 
            this.TSpointsPanel.Controls.Add(this.TSpointsAddGroupbox2);
            this.TSpointsPanel.Location = new System.Drawing.Point(284, 21);
            this.TSpointsPanel.Name = "TSpointsPanel";
            this.TSpointsPanel.Size = new System.Drawing.Size(586, 433);
            this.TSpointsPanel.TabIndex = 17;
            // 
            // TSpointsAddGroupbox2
            // 
            this.TSpointsAddGroupbox2.Controls.Add(this.groupBox2);
            this.TSpointsAddGroupbox2.Controls.Add(this.groupBox1);
            this.TSpointsAddGroupbox2.Controls.Add(this.TSpointsAddGroupbox);
            this.TSpointsAddGroupbox2.Location = new System.Drawing.Point(3, 3);
            this.TSpointsAddGroupbox2.Name = "TSpointsAddGroupbox2";
            this.TSpointsAddGroupbox2.Size = new System.Drawing.Size(580, 427);
            this.TSpointsAddGroupbox2.TabIndex = 7;
            this.TSpointsAddGroupbox2.TabStop = false;
            this.TSpointsAddGroupbox2.Text = "NOT KAYIT";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.TSpointsAddListview);
            this.groupBox2.Location = new System.Drawing.Point(6, 146);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(563, 124);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "ÖĞRENCİLER";
            // 
            // TSpointsAddListview
            // 
            this.TSpointsAddListview.HideSelection = false;
            this.TSpointsAddListview.Location = new System.Drawing.Point(15, 25);
            this.TSpointsAddListview.Name = "TSpointsAddListview";
            this.TSpointsAddListview.Size = new System.Drawing.Size(541, 89);
            this.TSpointsAddListview.TabIndex = 0;
            this.TSpointsAddListview.UseCompatibleStateImageBehavior = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TSpointsLecturesListView);
            this.groupBox1.Location = new System.Drawing.Point(6, 20);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(563, 124);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "DERSLERİM";
            // 
            // TSpointsLecturesListView
            // 
            this.TSpointsLecturesListView.HideSelection = false;
            this.TSpointsLecturesListView.Location = new System.Drawing.Point(15, 19);
            this.TSpointsLecturesListView.Name = "TSpointsLecturesListView";
            this.TSpointsLecturesListView.Size = new System.Drawing.Size(541, 89);
            this.TSpointsLecturesListView.TabIndex = 6;
            this.TSpointsLecturesListView.UseCompatibleStateImageBehavior = false;
            this.TSpointsLecturesListView.MouseClick += new System.Windows.Forms.MouseEventHandler(this.TSpointsLecturesListView_MouseClick);
            // 
            // TSpointsAddGroupbox
            // 
            this.TSpointsAddGroupbox.Controls.Add(this.TSpointsAddFinalLabel);
            this.TSpointsAddGroupbox.Controls.Add(this.TSpointsAddVizeLabel);
            this.TSpointsAddGroupbox.Controls.Add(this.TSpointsAddFinalTextbox);
            this.TSpointsAddGroupbox.Controls.Add(this.TSpointsAddBtn);
            this.TSpointsAddGroupbox.Controls.Add(this.TSpointsAddVizeTextbox);
            this.TSpointsAddGroupbox.Location = new System.Drawing.Point(6, 273);
            this.TSpointsAddGroupbox.Name = "TSpointsAddGroupbox";
            this.TSpointsAddGroupbox.Size = new System.Drawing.Size(563, 149);
            this.TSpointsAddGroupbox.TabIndex = 5;
            this.TSpointsAddGroupbox.TabStop = false;
            this.TSpointsAddGroupbox.Text = "NOT GİRİŞ ";
            // 
            // TSpointsAddFinalLabel
            // 
            this.TSpointsAddFinalLabel.AutoSize = true;
            this.TSpointsAddFinalLabel.Location = new System.Drawing.Point(36, 77);
            this.TSpointsAddFinalLabel.Name = "TSpointsAddFinalLabel";
            this.TSpointsAddFinalLabel.Size = new System.Drawing.Size(46, 17);
            this.TSpointsAddFinalLabel.TabIndex = 7;
            this.TSpointsAddFinalLabel.Text = "Final :";
            // 
            // TSpointsAddVizeLabel
            // 
            this.TSpointsAddVizeLabel.AutoSize = true;
            this.TSpointsAddVizeLabel.Location = new System.Drawing.Point(36, 33);
            this.TSpointsAddVizeLabel.Name = "TSpointsAddVizeLabel";
            this.TSpointsAddVizeLabel.Size = new System.Drawing.Size(43, 17);
            this.TSpointsAddVizeLabel.TabIndex = 6;
            this.TSpointsAddVizeLabel.Text = "Vize :";
            // 
            // TSpointsAddFinalTextbox
            // 
            this.TSpointsAddFinalTextbox.Location = new System.Drawing.Point(105, 74);
            this.TSpointsAddFinalTextbox.Name = "TSpointsAddFinalTextbox";
            this.TSpointsAddFinalTextbox.Size = new System.Drawing.Size(406, 22);
            this.TSpointsAddFinalTextbox.TabIndex = 3;
            // 
            // TSpointsAddBtn
            // 
            this.TSpointsAddBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.TSpointsAddBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.TSpointsAddBtn.Location = new System.Drawing.Point(105, 110);
            this.TSpointsAddBtn.Name = "TSpointsAddBtn";
            this.TSpointsAddBtn.Size = new System.Drawing.Size(406, 33);
            this.TSpointsAddBtn.TabIndex = 4;
            this.TSpointsAddBtn.Text = "KAYIT ET";
            this.TSpointsAddBtn.UseVisualStyleBackColor = true;
            this.TSpointsAddBtn.Click += new System.EventHandler(this.TSpointsAddBtn_Click);
            // 
            // TSpointsAddVizeTextbox
            // 
            this.TSpointsAddVizeTextbox.Location = new System.Drawing.Point(105, 33);
            this.TSpointsAddVizeTextbox.Name = "TSpointsAddVizeTextbox";
            this.TSpointsAddVizeTextbox.Size = new System.Drawing.Size(406, 22);
            this.TSpointsAddVizeTextbox.TabIndex = 2;
            // 
            // TSProfilePanel
            // 
            this.TSProfilePanel.Controls.Add(this.TSProfileGroupbox);
            this.TSProfilePanel.Location = new System.Drawing.Point(284, 21);
            this.TSProfilePanel.Name = "TSProfilePanel";
            this.TSProfilePanel.Size = new System.Drawing.Size(586, 433);
            this.TSProfilePanel.TabIndex = 17;
            // 
            // TSProfileGroupbox
            // 
            this.TSProfileGroupbox.Controls.Add(this.TSProfileAddNewSecurityWordBtn);
            this.TSProfileGroupbox.Controls.Add(this.TSProfileAddNewPswBtn);
            this.TSProfileGroupbox.Controls.Add(this.TSProfileNewSecurityWordBtn);
            this.TSProfileGroupbox.Controls.Add(this.TSProfileNewPswBtn);
            this.TSProfileGroupbox.Controls.Add(this.TSProfileNewSecurityWordTextbox);
            this.TSProfileGroupbox.Controls.Add(this.TSProfileNewPswTextbox);
            this.TSProfileGroupbox.Controls.Add(this.TSProfileInputSecurityWordLabel);
            this.TSProfileGroupbox.Controls.Add(this.TSProfileInputPswLabel);
            this.TSProfileGroupbox.Controls.Add(this.TSProfileInputProgramsLabel);
            this.TSProfileGroupbox.Controls.Add(this.TSProfileInputSurnameLabel);
            this.TSProfileGroupbox.Controls.Add(this.TSProfileInputNameLabel);
            this.TSProfileGroupbox.Controls.Add(this.TSProfileSecurityWordLabel);
            this.TSProfileGroupbox.Controls.Add(this.TSProfilePswLabel);
            this.TSProfileGroupbox.Controls.Add(this.TSProfilProgramsLabel);
            this.TSProfileGroupbox.Controls.Add(this.TSProfileSurnameLabel);
            this.TSProfileGroupbox.Controls.Add(this.TSProfileNameLabel);
            this.TSProfileGroupbox.Location = new System.Drawing.Point(51, 57);
            this.TSProfileGroupbox.Name = "TSProfileGroupbox";
            this.TSProfileGroupbox.Size = new System.Drawing.Size(462, 330);
            this.TSProfileGroupbox.TabIndex = 10;
            this.TSProfileGroupbox.TabStop = false;
            this.TSProfileGroupbox.Text = "PROFİLİM";
            // 
            // TSProfileAddNewSecurityWordBtn
            // 
            this.TSProfileAddNewSecurityWordBtn.Location = new System.Drawing.Point(346, 242);
            this.TSProfileAddNewSecurityWordBtn.Name = "TSProfileAddNewSecurityWordBtn";
            this.TSProfileAddNewSecurityWordBtn.Size = new System.Drawing.Size(81, 26);
            this.TSProfileAddNewSecurityWordBtn.TabIndex = 4;
            this.TSProfileAddNewSecurityWordBtn.Text = "Onayla";
            this.TSProfileAddNewSecurityWordBtn.UseVisualStyleBackColor = true;
            this.TSProfileAddNewSecurityWordBtn.Visible = false;
            this.TSProfileAddNewSecurityWordBtn.Click += new System.EventHandler(this.TSProfileAddNewSecurityWordBtn_Click);
            // 
            // TSProfileAddNewPswBtn
            // 
            this.TSProfileAddNewPswBtn.Location = new System.Drawing.Point(346, 189);
            this.TSProfileAddNewPswBtn.Name = "TSProfileAddNewPswBtn";
            this.TSProfileAddNewPswBtn.Size = new System.Drawing.Size(81, 26);
            this.TSProfileAddNewPswBtn.TabIndex = 5;
            this.TSProfileAddNewPswBtn.Text = "Onayla";
            this.TSProfileAddNewPswBtn.UseVisualStyleBackColor = true;
            this.TSProfileAddNewPswBtn.Visible = false;
            this.TSProfileAddNewPswBtn.Click += new System.EventHandler(this.TSProfileAddNewPswBtn_Click);
            // 
            // TSProfileNewSecurityWordBtn
            // 
            this.TSProfileNewSecurityWordBtn.Location = new System.Drawing.Point(346, 242);
            this.TSProfileNewSecurityWordBtn.Name = "TSProfileNewSecurityWordBtn";
            this.TSProfileNewSecurityWordBtn.Size = new System.Drawing.Size(81, 26);
            this.TSProfileNewSecurityWordBtn.TabIndex = 3;
            this.TSProfileNewSecurityWordBtn.Text = "Düzenle";
            this.TSProfileNewSecurityWordBtn.UseVisualStyleBackColor = true;
            this.TSProfileNewSecurityWordBtn.Click += new System.EventHandler(this.TSProfileNewSecurityWordBtn_Click);
            // 
            // TSProfileNewPswBtn
            // 
            this.TSProfileNewPswBtn.Location = new System.Drawing.Point(346, 190);
            this.TSProfileNewPswBtn.Name = "TSProfileNewPswBtn";
            this.TSProfileNewPswBtn.Size = new System.Drawing.Size(81, 26);
            this.TSProfileNewPswBtn.TabIndex = 2;
            this.TSProfileNewPswBtn.Text = "Düzenle";
            this.TSProfileNewPswBtn.UseVisualStyleBackColor = true;
            this.TSProfileNewPswBtn.Click += new System.EventHandler(this.TSProfileNewPswBtn_Click);
            // 
            // TSProfileNewSecurityWordTextbox
            // 
            this.TSProfileNewSecurityWordTextbox.Location = new System.Drawing.Point(204, 246);
            this.TSProfileNewSecurityWordTextbox.Name = "TSProfileNewSecurityWordTextbox";
            this.TSProfileNewSecurityWordTextbox.Size = new System.Drawing.Size(115, 22);
            this.TSProfileNewSecurityWordTextbox.TabIndex = 1;
            this.TSProfileNewSecurityWordTextbox.Visible = false;
            // 
            // TSProfileNewPswTextbox
            // 
            this.TSProfileNewPswTextbox.Location = new System.Drawing.Point(204, 194);
            this.TSProfileNewPswTextbox.Name = "TSProfileNewPswTextbox";
            this.TSProfileNewPswTextbox.Size = new System.Drawing.Size(115, 22);
            this.TSProfileNewPswTextbox.TabIndex = 0;
            this.TSProfileNewPswTextbox.Visible = false;
            // 
            // TSProfileInputSecurityWordLabel
            // 
            this.TSProfileInputSecurityWordLabel.AutoSize = true;
            this.TSProfileInputSecurityWordLabel.Location = new System.Drawing.Point(201, 249);
            this.TSProfileInputSecurityWordLabel.Name = "TSProfileInputSecurityWordLabel";
            this.TSProfileInputSecurityWordLabel.Size = new System.Drawing.Size(78, 17);
            this.TSProfileInputSecurityWordLabel.TabIndex = 9;
            this.TSProfileInputSecurityWordLabel.Text = "**************";
            // 
            // TSProfileInputPswLabel
            // 
            this.TSProfileInputPswLabel.AutoSize = true;
            this.TSProfileInputPswLabel.Location = new System.Drawing.Point(201, 199);
            this.TSProfileInputPswLabel.Name = "TSProfileInputPswLabel";
            this.TSProfileInputPswLabel.Size = new System.Drawing.Size(78, 17);
            this.TSProfileInputPswLabel.TabIndex = 8;
            this.TSProfileInputPswLabel.Text = "**************";
            // 
            // TSProfileInputProgramsLabel
            // 
            this.TSProfileInputProgramsLabel.AutoSize = true;
            this.TSProfileInputProgramsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold);
            this.TSProfileInputProgramsLabel.Location = new System.Drawing.Point(201, 147);
            this.TSProfileInputProgramsLabel.Name = "TSProfileInputProgramsLabel";
            this.TSProfileInputProgramsLabel.Size = new System.Drawing.Size(0, 20);
            this.TSProfileInputProgramsLabel.TabIndex = 7;
            // 
            // TSProfileInputSurnameLabel
            // 
            this.TSProfileInputSurnameLabel.AutoSize = true;
            this.TSProfileInputSurnameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold);
            this.TSProfileInputSurnameLabel.Location = new System.Drawing.Point(201, 100);
            this.TSProfileInputSurnameLabel.Name = "TSProfileInputSurnameLabel";
            this.TSProfileInputSurnameLabel.Size = new System.Drawing.Size(0, 20);
            this.TSProfileInputSurnameLabel.TabIndex = 6;
            // 
            // TSProfileInputNameLabel
            // 
            this.TSProfileInputNameLabel.AutoSize = true;
            this.TSProfileInputNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.TSProfileInputNameLabel.Location = new System.Drawing.Point(201, 55);
            this.TSProfileInputNameLabel.Name = "TSProfileInputNameLabel";
            this.TSProfileInputNameLabel.Size = new System.Drawing.Size(0, 20);
            this.TSProfileInputNameLabel.TabIndex = 5;
            // 
            // TSProfileSecurityWordLabel
            // 
            this.TSProfileSecurityWordLabel.AutoSize = true;
            this.TSProfileSecurityWordLabel.Location = new System.Drawing.Point(43, 249);
            this.TSProfileSecurityWordLabel.Name = "TSProfileSecurityWordLabel";
            this.TSProfileSecurityWordLabel.Size = new System.Drawing.Size(127, 17);
            this.TSProfileSecurityWordLabel.TabIndex = 4;
            this.TSProfileSecurityWordLabel.Text = "Güvenlik Kelimesi :";
            // 
            // TSProfilePswLabel
            // 
            this.TSProfilePswLabel.AutoSize = true;
            this.TSProfilePswLabel.Location = new System.Drawing.Point(43, 195);
            this.TSProfilePswLabel.Name = "TSProfilePswLabel";
            this.TSProfilePswLabel.Size = new System.Drawing.Size(45, 17);
            this.TSProfilePswLabel.TabIndex = 3;
            this.TSProfilePswLabel.Text = "Şifre :";
            // 
            // TSProfilProgramsLabel
            // 
            this.TSProfilProgramsLabel.AutoSize = true;
            this.TSProfilProgramsLabel.Location = new System.Drawing.Point(43, 147);
            this.TSProfilProgramsLabel.Name = "TSProfilProgramsLabel";
            this.TSProfilProgramsLabel.Size = new System.Drawing.Size(59, 17);
            this.TSProfilProgramsLabel.TabIndex = 2;
            this.TSProfilProgramsLabel.Text = "Bölüm : ";
            // 
            // TSProfileSurnameLabel
            // 
            this.TSProfileSurnameLabel.AutoSize = true;
            this.TSProfileSurnameLabel.Location = new System.Drawing.Point(43, 100);
            this.TSProfileSurnameLabel.Name = "TSProfileSurnameLabel";
            this.TSProfileSurnameLabel.Size = new System.Drawing.Size(64, 17);
            this.TSProfileSurnameLabel.TabIndex = 1;
            this.TSProfileSurnameLabel.Text = "Soyisim :";
            // 
            // TSProfileNameLabel
            // 
            this.TSProfileNameLabel.AutoSize = true;
            this.TSProfileNameLabel.Location = new System.Drawing.Point(43, 55);
            this.TSProfileNameLabel.Name = "TSProfileNameLabel";
            this.TSProfileNameLabel.Size = new System.Drawing.Size(44, 17);
            this.TSProfileNameLabel.TabIndex = 0;
            this.TSProfileNameLabel.Text = "İsim : ";
            // 
            // TSAddLecturesPanel
            // 
            this.TSAddLecturesPanel.Controls.Add(this.TSders_verListViewGroupbox);
            this.TSAddLecturesPanel.Location = new System.Drawing.Point(284, 21);
            this.TSAddLecturesPanel.Name = "TSAddLecturesPanel";
            this.TSAddLecturesPanel.Size = new System.Drawing.Size(586, 433);
            this.TSAddLecturesPanel.TabIndex = 9;
            // 
            // TSders_verListViewGroupbox
            // 
            this.TSders_verListViewGroupbox.Controls.Add(this.TSders_verAddBtn);
            this.TSders_verListViewGroupbox.Controls.Add(this.TSLectureAddListView);
            this.TSders_verListViewGroupbox.Location = new System.Drawing.Point(23, 30);
            this.TSders_verListViewGroupbox.Name = "TSders_verListViewGroupbox";
            this.TSders_verListViewGroupbox.Size = new System.Drawing.Size(533, 376);
            this.TSders_verListViewGroupbox.TabIndex = 5;
            this.TSders_verListViewGroupbox.TabStop = false;
            this.TSders_verListViewGroupbox.Text = "AÇIK BÖLÜM DERSLERİ";
            // 
            // TSders_verAddBtn
            // 
            this.TSders_verAddBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.TSders_verAddBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TSders_verAddBtn.Location = new System.Drawing.Point(20, 282);
            this.TSders_verAddBtn.Name = "TSders_verAddBtn";
            this.TSders_verAddBtn.Size = new System.Drawing.Size(494, 38);
            this.TSders_verAddBtn.TabIndex = 2;
            this.TSders_verAddBtn.Text = "DERSİ AL";
            this.TSders_verAddBtn.UseVisualStyleBackColor = true;
            this.TSders_verAddBtn.Click += new System.EventHandler(this.TSders_verAddBtn_Click);
            // 
            // TSLectureAddListView
            // 
            this.TSLectureAddListView.HideSelection = false;
            this.TSLectureAddListView.Location = new System.Drawing.Point(15, 50);
            this.TSLectureAddListView.Name = "TSLectureAddListView";
            this.TSLectureAddListView.Size = new System.Drawing.Size(509, 215);
            this.TSLectureAddListView.TabIndex = 0;
            this.TSLectureAddListView.UseCompatibleStateImageBehavior = false;
            // 
            // TSotherGroupbox
            // 
            this.TSotherGroupbox.BackColor = System.Drawing.Color.Transparent;
            this.TSotherGroupbox.Controls.Add(this.TSlecturesShowBtn);
            this.TSotherGroupbox.Controls.Add(this.TSLoginWelcomeLabel);
            this.TSotherGroupbox.Controls.Add(this.TSnoticePanelBtn);
            this.TSotherGroupbox.Controls.Add(this.TSexamsPanelBtn);
            this.TSotherGroupbox.Controls.Add(this.TSlecturesPanelBackBtn);
            this.TSotherGroupbox.Controls.Add(this.TSLecturesaddbtn);
            this.TSotherGroupbox.Location = new System.Drawing.Point(6, 40);
            this.TSotherGroupbox.Name = "TSotherGroupbox";
            this.TSotherGroupbox.Size = new System.Drawing.Size(272, 433);
            this.TSotherGroupbox.TabIndex = 7;
            this.TSotherGroupbox.TabStop = false;
            this.TSotherGroupbox.Text = "İŞLEMLER";
            // 
            // TSlecturesShowBtn
            // 
            this.TSlecturesShowBtn.BackgroundImage = global::EntityFramework.Properties.Resources.myLecture;
            this.TSlecturesShowBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.TSlecturesShowBtn.FlatAppearance.BorderSize = 0;
            this.TSlecturesShowBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.TSlecturesShowBtn.Location = new System.Drawing.Point(6, 36);
            this.TSlecturesShowBtn.Name = "TSlecturesShowBtn";
            this.TSlecturesShowBtn.Size = new System.Drawing.Size(259, 50);
            this.TSlecturesShowBtn.TabIndex = 1;
            this.TSlecturesShowBtn.UseVisualStyleBackColor = true;
            this.TSlecturesShowBtn.Click += new System.EventHandler(this.TSlecturesShowBtn_Click);
            // 
            // TSLoginWelcomeLabel
            // 
            this.TSLoginWelcomeLabel.AutoSize = true;
            this.TSLoginWelcomeLabel.Location = new System.Drawing.Point(23, 25);
            this.TSLoginWelcomeLabel.Name = "TSLoginWelcomeLabel";
            this.TSLoginWelcomeLabel.Size = new System.Drawing.Size(0, 17);
            this.TSLoginWelcomeLabel.TabIndex = 6;
            // 
            // TSnoticePanelBtn
            // 
            this.TSnoticePanelBtn.BackgroundImage = global::EntityFramework.Properties.Resources.profile_user;
            this.TSnoticePanelBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.TSnoticePanelBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.TSnoticePanelBtn.Location = new System.Drawing.Point(7, 268);
            this.TSnoticePanelBtn.Name = "TSnoticePanelBtn";
            this.TSnoticePanelBtn.Size = new System.Drawing.Size(259, 50);
            this.TSnoticePanelBtn.TabIndex = 4;
            this.TSnoticePanelBtn.UseVisualStyleBackColor = true;
            this.TSnoticePanelBtn.Click += new System.EventHandler(this.TSnoticePanelBtn_Click);
            // 
            // TSexamsPanelBtn
            // 
            this.TSexamsPanelBtn.BackgroundImage = global::EntityFramework.Properties.Resources.quiz;
            this.TSexamsPanelBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.TSexamsPanelBtn.FlatAppearance.BorderSize = 0;
            this.TSexamsPanelBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.TSexamsPanelBtn.Location = new System.Drawing.Point(6, 189);
            this.TSexamsPanelBtn.Name = "TSexamsPanelBtn";
            this.TSexamsPanelBtn.Size = new System.Drawing.Size(259, 50);
            this.TSexamsPanelBtn.TabIndex = 3;
            this.TSexamsPanelBtn.UseVisualStyleBackColor = true;
            this.TSexamsPanelBtn.Click += new System.EventHandler(this.TSexamsPanelBtn_Click);
            // 
            // TSlecturesPanelBackBtn
            // 
            this.TSlecturesPanelBackBtn.BackgroundImage = global::EntityFramework.Properties.Resources.enter;
            this.TSlecturesPanelBackBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.TSlecturesPanelBackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.TSlecturesPanelBackBtn.Location = new System.Drawing.Point(6, 347);
            this.TSlecturesPanelBackBtn.Name = "TSlecturesPanelBackBtn";
            this.TSlecturesPanelBackBtn.Size = new System.Drawing.Size(259, 50);
            this.TSlecturesPanelBackBtn.TabIndex = 5;
            this.TSlecturesPanelBackBtn.UseVisualStyleBackColor = true;
            this.TSlecturesPanelBackBtn.Click += new System.EventHandler(this.TSlecturesPanelBackBtn_Click);
            // 
            // TSLecturesaddbtn
            // 
            this.TSLecturesaddbtn.BackgroundImage = global::EntityFramework.Properties.Resources.lectures;
            this.TSLecturesaddbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.TSLecturesaddbtn.FlatAppearance.BorderSize = 0;
            this.TSLecturesaddbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.TSLecturesaddbtn.Location = new System.Drawing.Point(7, 116);
            this.TSLecturesaddbtn.Name = "TSLecturesaddbtn";
            this.TSLecturesaddbtn.Size = new System.Drawing.Size(259, 50);
            this.TSLecturesaddbtn.TabIndex = 2;
            this.TSLecturesaddbtn.UseVisualStyleBackColor = true;
            this.TSLecturesaddbtn.Click += new System.EventHandler(this.TSLecturesaddbtn_Click);
            // 
            // stdControlPanel
            // 
            this.stdControlPanel.BackColor = System.Drawing.Color.Transparent;
            this.stdControlPanel.Controls.Add(this.stdLecturesPanel);
            this.stdControlPanel.Controls.Add(this.stdOldLecturesPanel);
            this.stdControlPanel.Controls.Add(this.stdPointsPanel);
            this.stdControlPanel.Controls.Add(this.stdLecturesAddPanel);
            this.stdControlPanel.Controls.Add(this.stdProfilePanel);
            this.stdControlPanel.Controls.Add(this.stdControlTransactionGroupbox);
            this.stdControlPanel.Location = new System.Drawing.Point(96, 41);
            this.stdControlPanel.Name = "stdControlPanel";
            this.stdControlPanel.Size = new System.Drawing.Size(909, 517);
            this.stdControlPanel.TabIndex = 10;
            // 
            // stdLecturesPanel
            // 
            this.stdLecturesPanel.BackColor = System.Drawing.Color.Transparent;
            this.stdLecturesPanel.Controls.Add(this.stdLecturesShowGroupbox);
            this.stdLecturesPanel.Location = new System.Drawing.Point(252, 61);
            this.stdLecturesPanel.Name = "stdLecturesPanel";
            this.stdLecturesPanel.Size = new System.Drawing.Size(611, 419);
            this.stdLecturesPanel.TabIndex = 1;
            // 
            // stdLecturesShowGroupbox
            // 
            this.stdLecturesShowGroupbox.BackColor = System.Drawing.Color.Transparent;
            this.stdLecturesShowGroupbox.Controls.Add(this.stdLecturesShowListView);
            this.stdLecturesShowGroupbox.Location = new System.Drawing.Point(34, 39);
            this.stdLecturesShowGroupbox.Name = "stdLecturesShowGroupbox";
            this.stdLecturesShowGroupbox.Size = new System.Drawing.Size(561, 364);
            this.stdLecturesShowGroupbox.TabIndex = 1;
            this.stdLecturesShowGroupbox.TabStop = false;
            this.stdLecturesShowGroupbox.Text = "DERSLERİN";
            // 
            // stdLecturesShowListView
            // 
            this.stdLecturesShowListView.HideSelection = false;
            this.stdLecturesShowListView.Location = new System.Drawing.Point(49, 21);
            this.stdLecturesShowListView.Name = "stdLecturesShowListView";
            this.stdLecturesShowListView.Size = new System.Drawing.Size(462, 323);
            this.stdLecturesShowListView.TabIndex = 0;
            this.stdLecturesShowListView.UseCompatibleStateImageBehavior = false;
            // 
            // stdOldLecturesPanel
            // 
            this.stdOldLecturesPanel.Controls.Add(this.stdOldLecturesListviewGroupbox);
            this.stdOldLecturesPanel.Location = new System.Drawing.Point(252, 61);
            this.stdOldLecturesPanel.Name = "stdOldLecturesPanel";
            this.stdOldLecturesPanel.Size = new System.Drawing.Size(611, 419);
            this.stdOldLecturesPanel.TabIndex = 7;
            // 
            // stdOldLecturesListviewGroupbox
            // 
            this.stdOldLecturesListviewGroupbox.Controls.Add(this.stdOldLecturesAddBtn);
            this.stdOldLecturesListviewGroupbox.Controls.Add(this.stdOldLecturesPanellistView);
            this.stdOldLecturesListviewGroupbox.Location = new System.Drawing.Point(16, 29);
            this.stdOldLecturesListviewGroupbox.Name = "stdOldLecturesListviewGroupbox";
            this.stdOldLecturesListviewGroupbox.Size = new System.Drawing.Size(574, 354);
            this.stdOldLecturesListviewGroupbox.TabIndex = 1;
            this.stdOldLecturesListviewGroupbox.TabStop = false;
            this.stdOldLecturesListviewGroupbox.Text = "Verilmeyen Dersler";
            // 
            // stdOldLecturesPanellistView
            // 
            this.stdOldLecturesPanellistView.HideSelection = false;
            this.stdOldLecturesPanellistView.Location = new System.Drawing.Point(32, 28);
            this.stdOldLecturesPanellistView.Name = "stdOldLecturesPanellistView";
            this.stdOldLecturesPanellistView.Size = new System.Drawing.Size(513, 238);
            this.stdOldLecturesPanellistView.TabIndex = 0;
            this.stdOldLecturesPanellistView.UseCompatibleStateImageBehavior = false;
            // 
            // stdPointsPanel
            // 
            this.stdPointsPanel.BackColor = System.Drawing.Color.Transparent;
            this.stdPointsPanel.Controls.Add(this.stdPointListViewGroupbox);
            this.stdPointsPanel.Location = new System.Drawing.Point(252, 61);
            this.stdPointsPanel.Name = "stdPointsPanel";
            this.stdPointsPanel.Size = new System.Drawing.Size(611, 419);
            this.stdPointsPanel.TabIndex = 3;
            // 
            // stdPointListViewGroupbox
            // 
            this.stdPointListViewGroupbox.BackColor = System.Drawing.Color.Transparent;
            this.stdPointListViewGroupbox.Controls.Add(this.stdPointListView);
            this.stdPointListViewGroupbox.Location = new System.Drawing.Point(24, 39);
            this.stdPointListViewGroupbox.Name = "stdPointListViewGroupbox";
            this.stdPointListViewGroupbox.Size = new System.Drawing.Size(571, 364);
            this.stdPointListViewGroupbox.TabIndex = 1;
            this.stdPointListViewGroupbox.TabStop = false;
            this.stdPointListViewGroupbox.Text = "NOTLARIM";
            // 
            // stdPointListView
            // 
            this.stdPointListView.HideSelection = false;
            this.stdPointListView.Location = new System.Drawing.Point(49, 21);
            this.stdPointListView.Name = "stdPointListView";
            this.stdPointListView.Size = new System.Drawing.Size(462, 323);
            this.stdPointListView.TabIndex = 0;
            this.stdPointListView.UseCompatibleStateImageBehavior = false;
            // 
            // stdLecturesAddPanel
            // 
            this.stdLecturesAddPanel.BackColor = System.Drawing.Color.Transparent;
            this.stdLecturesAddPanel.Controls.Add(this.stdLectureAddGroupbox);
            this.stdLecturesAddPanel.Location = new System.Drawing.Point(252, 61);
            this.stdLecturesAddPanel.Name = "stdLecturesAddPanel";
            this.stdLecturesAddPanel.Size = new System.Drawing.Size(611, 419);
            this.stdLecturesAddPanel.TabIndex = 2;
            // 
            // stdLectureAddGroupbox
            // 
            this.stdLectureAddGroupbox.Controls.Add(this.stdLecturesAddBtn);
            this.stdLectureAddGroupbox.Controls.Add(this.stdLecturesAddListView);
            this.stdLectureAddGroupbox.Location = new System.Drawing.Point(39, 23);
            this.stdLectureAddGroupbox.Name = "stdLectureAddGroupbox";
            this.stdLectureAddGroupbox.Size = new System.Drawing.Size(522, 344);
            this.stdLectureAddGroupbox.TabIndex = 2;
            this.stdLectureAddGroupbox.TabStop = false;
            this.stdLectureAddGroupbox.Text = "DERS SEÇ";
            // 
            // stdLecturesAddBtn
            // 
            this.stdLecturesAddBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.stdLecturesAddBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.stdLecturesAddBtn.Location = new System.Drawing.Point(19, 292);
            this.stdLecturesAddBtn.Name = "stdLecturesAddBtn";
            this.stdLecturesAddBtn.Size = new System.Drawing.Size(475, 37);
            this.stdLecturesAddBtn.TabIndex = 1;
            this.stdLecturesAddBtn.Text = "EKLE";
            this.stdLecturesAddBtn.UseVisualStyleBackColor = true;
            this.stdLecturesAddBtn.Click += new System.EventHandler(this.stdLecturesAddBtn_Click);
            // 
            // stdLecturesAddListView
            // 
            this.stdLecturesAddListView.HideSelection = false;
            this.stdLecturesAddListView.Location = new System.Drawing.Point(19, 29);
            this.stdLecturesAddListView.Name = "stdLecturesAddListView";
            this.stdLecturesAddListView.Size = new System.Drawing.Size(475, 255);
            this.stdLecturesAddListView.TabIndex = 0;
            this.stdLecturesAddListView.UseCompatibleStateImageBehavior = false;
            // 
            // stdProfilePanel
            // 
            this.stdProfilePanel.BackColor = System.Drawing.Color.Transparent;
            this.stdProfilePanel.Controls.Add(this.stdProfileİnformationGroupbox);
            this.stdProfilePanel.Location = new System.Drawing.Point(252, 61);
            this.stdProfilePanel.Name = "stdProfilePanel";
            this.stdProfilePanel.Size = new System.Drawing.Size(611, 419);
            this.stdProfilePanel.TabIndex = 6;
            // 
            // stdProfileİnformationGroupbox
            // 
            this.stdProfileİnformationGroupbox.Controls.Add(this.stdNewPswBtn);
            this.stdProfileİnformationGroupbox.Controls.Add(this.stdNewSecurityWordBtn);
            this.stdProfileİnformationGroupbox.Controls.Add(this.stdNewSecurityWordTextbox);
            this.stdProfileİnformationGroupbox.Controls.Add(this.stdNewPswTextbox);
            this.stdProfileİnformationGroupbox.Controls.Add(this.stdProfileNewSecurityWordPanelBtn);
            this.stdProfileİnformationGroupbox.Controls.Add(this.stdProfileNewPswPanelBtn);
            this.stdProfileİnformationGroupbox.Controls.Add(this.stdProfileInputSecurityWordLabel);
            this.stdProfileİnformationGroupbox.Controls.Add(this.stdProfileInputPswLabel);
            this.stdProfileİnformationGroupbox.Controls.Add(this.stdProfileInputProgramsLabel);
            this.stdProfileİnformationGroupbox.Controls.Add(this.stdProfileInputsurnameLabel);
            this.stdProfileİnformationGroupbox.Controls.Add(this.stdProfileInputNameLabel);
            this.stdProfileİnformationGroupbox.Controls.Add(this.stdProfileSecurityWordLabel);
            this.stdProfileİnformationGroupbox.Controls.Add(this.stdProfilePswLabel);
            this.stdProfileİnformationGroupbox.Controls.Add(this.stdProfileProgramsLabel);
            this.stdProfileİnformationGroupbox.Controls.Add(this.stdProfileSurnameLabel);
            this.stdProfileİnformationGroupbox.Controls.Add(this.stdProfileNameLabel);
            this.stdProfileİnformationGroupbox.Location = new System.Drawing.Point(43, 43);
            this.stdProfileİnformationGroupbox.Name = "stdProfileİnformationGroupbox";
            this.stdProfileİnformationGroupbox.Size = new System.Drawing.Size(511, 341);
            this.stdProfileİnformationGroupbox.TabIndex = 1;
            this.stdProfileİnformationGroupbox.TabStop = false;
            this.stdProfileİnformationGroupbox.Text = "PROFİLİM";
            // 
            // stdNewPswBtn
            // 
            this.stdNewPswBtn.Location = new System.Drawing.Point(399, 201);
            this.stdNewPswBtn.Name = "stdNewPswBtn";
            this.stdNewPswBtn.Size = new System.Drawing.Size(75, 34);
            this.stdNewPswBtn.TabIndex = 13;
            this.stdNewPswBtn.Text = "Onayla";
            this.stdNewPswBtn.UseVisualStyleBackColor = true;
            this.stdNewPswBtn.Visible = false;
            this.stdNewPswBtn.Click += new System.EventHandler(this.stdNewPswBtn_Click);
            // 
            // stdNewSecurityWordBtn
            // 
            this.stdNewSecurityWordBtn.Location = new System.Drawing.Point(399, 255);
            this.stdNewSecurityWordBtn.Name = "stdNewSecurityWordBtn";
            this.stdNewSecurityWordBtn.Size = new System.Drawing.Size(75, 34);
            this.stdNewSecurityWordBtn.TabIndex = 12;
            this.stdNewSecurityWordBtn.Text = "Onayla";
            this.stdNewSecurityWordBtn.UseVisualStyleBackColor = true;
            this.stdNewSecurityWordBtn.Visible = false;
            this.stdNewSecurityWordBtn.Click += new System.EventHandler(this.stdNewSecurityWordBtn_Click);
            // 
            // stdNewSecurityWordTextbox
            // 
            this.stdNewSecurityWordTextbox.Location = new System.Drawing.Point(237, 263);
            this.stdNewSecurityWordTextbox.Name = "stdNewSecurityWordTextbox";
            this.stdNewSecurityWordTextbox.Size = new System.Drawing.Size(122, 22);
            this.stdNewSecurityWordTextbox.TabIndex = 11;
            this.stdNewSecurityWordTextbox.Visible = false;
            // 
            // stdNewPswTextbox
            // 
            this.stdNewPswTextbox.Location = new System.Drawing.Point(237, 209);
            this.stdNewPswTextbox.Name = "stdNewPswTextbox";
            this.stdNewPswTextbox.Size = new System.Drawing.Size(122, 22);
            this.stdNewPswTextbox.TabIndex = 10;
            this.stdNewPswTextbox.Visible = false;
            // 
            // stdProfileNewSecurityWordPanelBtn
            // 
            this.stdProfileNewSecurityWordPanelBtn.Location = new System.Drawing.Point(399, 254);
            this.stdProfileNewSecurityWordPanelBtn.Name = "stdProfileNewSecurityWordPanelBtn";
            this.stdProfileNewSecurityWordPanelBtn.Size = new System.Drawing.Size(75, 34);
            this.stdProfileNewSecurityWordPanelBtn.TabIndex = 1;
            this.stdProfileNewSecurityWordPanelBtn.Text = "Değiştir";
            this.stdProfileNewSecurityWordPanelBtn.UseVisualStyleBackColor = true;
            this.stdProfileNewSecurityWordPanelBtn.Click += new System.EventHandler(this.stdProfileNewSecurityWordPanelBtn_Click);
            // 
            // stdProfileNewPswPanelBtn
            // 
            this.stdProfileNewPswPanelBtn.Location = new System.Drawing.Point(399, 201);
            this.stdProfileNewPswPanelBtn.Name = "stdProfileNewPswPanelBtn";
            this.stdProfileNewPswPanelBtn.Size = new System.Drawing.Size(75, 34);
            this.stdProfileNewPswPanelBtn.TabIndex = 0;
            this.stdProfileNewPswPanelBtn.Text = "Değiştir";
            this.stdProfileNewPswPanelBtn.UseVisualStyleBackColor = true;
            this.stdProfileNewPswPanelBtn.Click += new System.EventHandler(this.stdProfileNewPswPanelBtn_Click);
            // 
            // stdProfileInputSecurityWordLabel
            // 
            this.stdProfileInputSecurityWordLabel.AutoSize = true;
            this.stdProfileInputSecurityWordLabel.Location = new System.Drawing.Point(234, 263);
            this.stdProfileInputSecurityWordLabel.Name = "stdProfileInputSecurityWordLabel";
            this.stdProfileInputSecurityWordLabel.Size = new System.Drawing.Size(88, 17);
            this.stdProfileInputSecurityWordLabel.TabIndex = 9;
            this.stdProfileInputSecurityWordLabel.Text = "****************";
            // 
            // stdProfileInputPswLabel
            // 
            this.stdProfileInputPswLabel.AutoSize = true;
            this.stdProfileInputPswLabel.Location = new System.Drawing.Point(234, 211);
            this.stdProfileInputPswLabel.Name = "stdProfileInputPswLabel";
            this.stdProfileInputPswLabel.Size = new System.Drawing.Size(88, 17);
            this.stdProfileInputPswLabel.TabIndex = 8;
            this.stdProfileInputPswLabel.Text = "****************";
            // 
            // stdProfileInputProgramsLabel
            // 
            this.stdProfileInputProgramsLabel.AutoSize = true;
            this.stdProfileInputProgramsLabel.Location = new System.Drawing.Point(234, 163);
            this.stdProfileInputProgramsLabel.Name = "stdProfileInputProgramsLabel";
            this.stdProfileInputProgramsLabel.Size = new System.Drawing.Size(0, 17);
            this.stdProfileInputProgramsLabel.TabIndex = 7;
            // 
            // stdProfileInputsurnameLabel
            // 
            this.stdProfileInputsurnameLabel.AutoSize = true;
            this.stdProfileInputsurnameLabel.Location = new System.Drawing.Point(234, 111);
            this.stdProfileInputsurnameLabel.Name = "stdProfileInputsurnameLabel";
            this.stdProfileInputsurnameLabel.Size = new System.Drawing.Size(0, 17);
            this.stdProfileInputsurnameLabel.TabIndex = 6;
            // 
            // stdProfileInputNameLabel
            // 
            this.stdProfileInputNameLabel.AutoSize = true;
            this.stdProfileInputNameLabel.Location = new System.Drawing.Point(234, 76);
            this.stdProfileInputNameLabel.Name = "stdProfileInputNameLabel";
            this.stdProfileInputNameLabel.Size = new System.Drawing.Size(0, 17);
            this.stdProfileInputNameLabel.TabIndex = 5;
            // 
            // stdProfileSecurityWordLabel
            // 
            this.stdProfileSecurityWordLabel.AutoSize = true;
            this.stdProfileSecurityWordLabel.Location = new System.Drawing.Point(90, 263);
            this.stdProfileSecurityWordLabel.Name = "stdProfileSecurityWordLabel";
            this.stdProfileSecurityWordLabel.Size = new System.Drawing.Size(120, 17);
            this.stdProfileSecurityWordLabel.TabIndex = 4;
            this.stdProfileSecurityWordLabel.Text = "Güvenlik Sorusu :";
            // 
            // stdProfilePswLabel
            // 
            this.stdProfilePswLabel.AutoSize = true;
            this.stdProfilePswLabel.Location = new System.Drawing.Point(89, 209);
            this.stdProfilePswLabel.Name = "stdProfilePswLabel";
            this.stdProfilePswLabel.Size = new System.Drawing.Size(49, 17);
            this.stdProfilePswLabel.TabIndex = 3;
            this.stdProfilePswLabel.Text = "Şifre : ";
            // 
            // stdProfileProgramsLabel
            // 
            this.stdProfileProgramsLabel.AutoSize = true;
            this.stdProfileProgramsLabel.Location = new System.Drawing.Point(89, 157);
            this.stdProfileProgramsLabel.Name = "stdProfileProgramsLabel";
            this.stdProfileProgramsLabel.Size = new System.Drawing.Size(59, 17);
            this.stdProfileProgramsLabel.TabIndex = 2;
            this.stdProfileProgramsLabel.Text = "Bölüm : ";
            // 
            // stdProfileSurnameLabel
            // 
            this.stdProfileSurnameLabel.AutoSize = true;
            this.stdProfileSurnameLabel.Location = new System.Drawing.Point(89, 111);
            this.stdProfileSurnameLabel.Name = "stdProfileSurnameLabel";
            this.stdProfileSurnameLabel.Size = new System.Drawing.Size(68, 17);
            this.stdProfileSurnameLabel.TabIndex = 1;
            this.stdProfileSurnameLabel.Text = "Soyisim : ";
            // 
            // stdProfileNameLabel
            // 
            this.stdProfileNameLabel.AutoSize = true;
            this.stdProfileNameLabel.Location = new System.Drawing.Point(89, 72);
            this.stdProfileNameLabel.Name = "stdProfileNameLabel";
            this.stdProfileNameLabel.Size = new System.Drawing.Size(44, 17);
            this.stdProfileNameLabel.TabIndex = 0;
            this.stdProfileNameLabel.Text = "İsim : ";
            // 
            // stdControlTransactionGroupbox
            // 
            this.stdControlTransactionGroupbox.BackColor = System.Drawing.Color.Transparent;
            this.stdControlTransactionGroupbox.Controls.Add(this.stdOldLecturesPanelbtn);
            this.stdControlTransactionGroupbox.Controls.Add(this.stdControlPanelBackBtn);
            this.stdControlTransactionGroupbox.Controls.Add(this.stdLecturesPanelBtn);
            this.stdControlTransactionGroupbox.Controls.Add(this.stdProfilePanelBtn);
            this.stdControlTransactionGroupbox.Controls.Add(this.stdLecturesAddPanelBtn);
            this.stdControlTransactionGroupbox.Controls.Add(this.stdPointsPanelBtn);
            this.stdControlTransactionGroupbox.Location = new System.Drawing.Point(39, 21);
            this.stdControlTransactionGroupbox.Name = "stdControlTransactionGroupbox";
            this.stdControlTransactionGroupbox.Size = new System.Drawing.Size(187, 459);
            this.stdControlTransactionGroupbox.TabIndex = 5;
            this.stdControlTransactionGroupbox.TabStop = false;
            this.stdControlTransactionGroupbox.Text = "İŞLEMLER";
            // 
            // stdOldLecturesPanelbtn
            // 
            this.stdOldLecturesPanelbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.stdOldLecturesPanelbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.stdOldLecturesPanelbtn.Location = new System.Drawing.Point(6, 318);
            this.stdOldLecturesPanelbtn.Name = "stdOldLecturesPanelbtn";
            this.stdOldLecturesPanelbtn.Size = new System.Drawing.Size(168, 50);
            this.stdOldLecturesPanelbtn.TabIndex = 5;
            this.stdOldLecturesPanelbtn.Text = "KALDIĞIN DERSLER";
            this.stdOldLecturesPanelbtn.UseVisualStyleBackColor = true;
            this.stdOldLecturesPanelbtn.Click += new System.EventHandler(this.stdOldLecturesPanelbtn_Click);
            // 
            // stdControlPanelBackBtn
            // 
            this.stdControlPanelBackBtn.BackgroundImage = global::EntityFramework.Properties.Resources.enter;
            this.stdControlPanelBackBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.stdControlPanelBackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.stdControlPanelBackBtn.Location = new System.Drawing.Point(6, 387);
            this.stdControlPanelBackBtn.Name = "stdControlPanelBackBtn";
            this.stdControlPanelBackBtn.Size = new System.Drawing.Size(168, 50);
            this.stdControlPanelBackBtn.TabIndex = 4;
            this.stdControlPanelBackBtn.UseVisualStyleBackColor = true;
            this.stdControlPanelBackBtn.Click += new System.EventHandler(this.stdControlPanelBackBtn_Click);
            // 
            // stdLecturesPanelBtn
            // 
            this.stdLecturesPanelBtn.BackgroundImage = global::EntityFramework.Properties.Resources.tablet;
            this.stdLecturesPanelBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.stdLecturesPanelBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.stdLecturesPanelBtn.Location = new System.Drawing.Point(6, 21);
            this.stdLecturesPanelBtn.Name = "stdLecturesPanelBtn";
            this.stdLecturesPanelBtn.Size = new System.Drawing.Size(168, 50);
            this.stdLecturesPanelBtn.TabIndex = 0;
            this.stdLecturesPanelBtn.UseVisualStyleBackColor = true;
            this.stdLecturesPanelBtn.Click += new System.EventHandler(this.stdLecturesPanelBtn_Click);
            // 
            // stdProfilePanelBtn
            // 
            this.stdProfilePanelBtn.BackgroundImage = global::EntityFramework.Properties.Resources.profile_user;
            this.stdProfilePanelBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.stdProfilePanelBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.stdProfilePanelBtn.Location = new System.Drawing.Point(6, 248);
            this.stdProfilePanelBtn.Name = "stdProfilePanelBtn";
            this.stdProfilePanelBtn.Size = new System.Drawing.Size(168, 50);
            this.stdProfilePanelBtn.TabIndex = 3;
            this.stdProfilePanelBtn.UseVisualStyleBackColor = true;
            this.stdProfilePanelBtn.Click += new System.EventHandler(this.stdProfilePanelBtn_Click);
            // 
            // stdLecturesAddPanelBtn
            // 
            this.stdLecturesAddPanelBtn.BackgroundImage = global::EntityFramework.Properties.Resources.add_button;
            this.stdLecturesAddPanelBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.stdLecturesAddPanelBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.stdLecturesAddPanelBtn.Location = new System.Drawing.Point(6, 95);
            this.stdLecturesAddPanelBtn.Name = "stdLecturesAddPanelBtn";
            this.stdLecturesAddPanelBtn.Size = new System.Drawing.Size(168, 50);
            this.stdLecturesAddPanelBtn.TabIndex = 1;
            this.stdLecturesAddPanelBtn.UseVisualStyleBackColor = true;
            this.stdLecturesAddPanelBtn.Click += new System.EventHandler(this.stdLecturesAddPanelBtn_Click);
            // 
            // stdPointsPanelBtn
            // 
            this.stdPointsPanelBtn.BackgroundImage = global::EntityFramework.Properties.Resources.quiz;
            this.stdPointsPanelBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.stdPointsPanelBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.stdPointsPanelBtn.Location = new System.Drawing.Point(6, 171);
            this.stdPointsPanelBtn.Name = "stdPointsPanelBtn";
            this.stdPointsPanelBtn.Size = new System.Drawing.Size(168, 50);
            this.stdPointsPanelBtn.TabIndex = 2;
            this.stdPointsPanelBtn.UseVisualStyleBackColor = true;
            this.stdPointsPanelBtn.Click += new System.EventHandler(this.stdPointsPanelBtn_Click);
            // 
            // CloseBtn
            // 
            this.CloseBtn.BackColor = System.Drawing.Color.Transparent;
            this.CloseBtn.FlatAppearance.BorderSize = 0;
            this.CloseBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CloseBtn.Location = new System.Drawing.Point(1037, 0);
            this.CloseBtn.Name = "CloseBtn";
            this.CloseBtn.Size = new System.Drawing.Size(40, 23);
            this.CloseBtn.TabIndex = 17;
            this.CloseBtn.Text = "X";
            this.CloseBtn.UseVisualStyleBackColor = false;
            this.CloseBtn.Click += new System.EventHandler(this.CloseBtn_Click);
            // 
            // periodPanel
            // 
            this.periodPanel.Controls.Add(this.PeriodInsertGroupbox);
            this.periodPanel.Location = new System.Drawing.Point(96, 41);
            this.periodPanel.Name = "periodPanel";
            this.periodPanel.Size = new System.Drawing.Size(909, 517);
            this.periodPanel.TabIndex = 18;
            // 
            // PeriodInsertGroupbox
            // 
            this.PeriodInsertGroupbox.Controls.Add(this.periodPanelBackBtn);
            this.PeriodInsertGroupbox.Controls.Add(this.PeriodInsertBtn);
            this.PeriodInsertGroupbox.Controls.Add(this.PeriodInsertNamecomboBox);
            this.PeriodInsertGroupbox.Controls.Add(this.periodInsertNameLabel);
            this.PeriodInsertGroupbox.Location = new System.Drawing.Point(172, 121);
            this.PeriodInsertGroupbox.Name = "PeriodInsertGroupbox";
            this.PeriodInsertGroupbox.Size = new System.Drawing.Size(551, 254);
            this.PeriodInsertGroupbox.TabIndex = 3;
            this.PeriodInsertGroupbox.TabStop = false;
            this.PeriodInsertGroupbox.Text = "Dönem seç";
            // 
            // periodPanelBackBtn
            // 
            this.periodPanelBackBtn.Location = new System.Drawing.Point(183, 199);
            this.periodPanelBackBtn.Name = "periodPanelBackBtn";
            this.periodPanelBackBtn.Size = new System.Drawing.Size(224, 35);
            this.periodPanelBackBtn.TabIndex = 3;
            this.periodPanelBackBtn.Text = "GERİ";
            this.periodPanelBackBtn.UseVisualStyleBackColor = true;
            this.periodPanelBackBtn.Click += new System.EventHandler(this.periodPanelBackBtn_Click);
            // 
            // PeriodInsertBtn
            // 
            this.PeriodInsertBtn.Location = new System.Drawing.Point(183, 148);
            this.PeriodInsertBtn.Name = "PeriodInsertBtn";
            this.PeriodInsertBtn.Size = new System.Drawing.Size(224, 35);
            this.PeriodInsertBtn.TabIndex = 2;
            this.PeriodInsertBtn.Text = "KAYIT ET";
            this.PeriodInsertBtn.UseVisualStyleBackColor = true;
            this.PeriodInsertBtn.Click += new System.EventHandler(this.PeriodInsertBtn_Click);
            // 
            // PeriodInsertNamecomboBox
            // 
            this.PeriodInsertNamecomboBox.FormattingEnabled = true;
            this.PeriodInsertNamecomboBox.Location = new System.Drawing.Point(185, 89);
            this.PeriodInsertNamecomboBox.Name = "PeriodInsertNamecomboBox";
            this.PeriodInsertNamecomboBox.Size = new System.Drawing.Size(222, 24);
            this.PeriodInsertNamecomboBox.TabIndex = 1;
            // 
            // periodInsertNameLabel
            // 
            this.periodInsertNameLabel.AutoSize = true;
            this.periodInsertNameLabel.Location = new System.Drawing.Point(23, 92);
            this.periodInsertNameLabel.Name = "periodInsertNameLabel";
            this.periodInsertNameLabel.Size = new System.Drawing.Size(81, 17);
            this.periodInsertNameLabel.TabIndex = 0;
            this.periodInsertNameLabel.Text = "Dönemler : ";
            // 
            // stdOldLecturesAddBtn
            // 
            this.stdOldLecturesAddBtn.Location = new System.Drawing.Point(32, 290);
            this.stdOldLecturesAddBtn.Name = "stdOldLecturesAddBtn";
            this.stdOldLecturesAddBtn.Size = new System.Drawing.Size(168, 50);
            this.stdOldLecturesAddBtn.TabIndex = 1;
            this.stdOldLecturesAddBtn.Text = "DERSİ AL";
            this.stdOldLecturesAddBtn.UseVisualStyleBackColor = true;
            this.stdOldLecturesAddBtn.Click += new System.EventHandler(this.stdOldLecturesAddBtn_Click);
            // 
            // aaa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1077, 639);
            this.Controls.Add(this.loginPanel);
            this.Controls.Add(this.stdGridViewPanel);
            this.Controls.Add(this.dellPanel);
            this.Controls.Add(this.CloseBtn);
            this.Controls.Add(this.teachingstaffAddpanel);
            this.Controls.Add(this.StdaddPanel);
            this.Controls.Add(this.TScontrolPanel);
            this.Controls.Add(this.TSgridViewPanel);
            this.Controls.Add(this.periodPanel);
            this.Controls.Add(this.stdControlPanel);
            this.Controls.Add(this.adminPanel);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "aaa";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.aaa_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.aaa_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.aaa_MouseUp);
            this.loginPanel.ResumeLayout(false);
            this.LogInGroupBox.ResumeLayout(false);
            this.LogInGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.STATUpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PSWpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.IDpictureBox)).EndInit();
            this.adminPanel.ResumeLayout(false);
            this.adminControlPanelGroupbox.ResumeLayout(false);
            this.teachingstaffAddpanel.ResumeLayout(false);
            this.Teachingstaffaddgroupbox.ResumeLayout(false);
            this.Teachingstaffaddgroupbox.PerformLayout();
            this.StdaddPanel.ResumeLayout(false);
            this.stdAddGroupbox.ResumeLayout(false);
            this.stdAddGroupbox.PerformLayout();
            this.dellPanel.ResumeLayout(false);
            this.dellGroupbox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dellDatagridView)).EndInit();
            this.dellInputGroupbox.ResumeLayout(false);
            this.dellInputGroupbox.PerformLayout();
            this.TSgridViewPanel.ResumeLayout(false);
            this.TSgridViewUpdateGroupbox.ResumeLayout(false);
            this.TSgridViewUpdateGroupbox.PerformLayout();
            this.TSsearchGroupbox.ResumeLayout(false);
            this.TSsearchGroupbox.PerformLayout();
            this.TSgridViewGroupbox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.TSgridView)).EndInit();
            this.stdGridViewPanel.ResumeLayout(false);
            this.stdGridviewUpdateGroupbox.ResumeLayout(false);
            this.stdGridviewUpdateGroupbox.PerformLayout();
            this.stdGridViewSearchGroupbox.ResumeLayout(false);
            this.stdGridViewSearchGroupbox.PerformLayout();
            this.stdGridViewGroupbox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.stdDataGridView)).EndInit();
            this.TScontrolPanel.ResumeLayout(false);
            this.TScontrolGroupbox.ResumeLayout(false);
            this.TSlecturesPanel.ResumeLayout(false);
            this.TSlecturesGroupbox.ResumeLayout(false);
            this.TSpointsPanel.ResumeLayout(false);
            this.TSpointsAddGroupbox2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.TSpointsAddGroupbox.ResumeLayout(false);
            this.TSpointsAddGroupbox.PerformLayout();
            this.TSProfilePanel.ResumeLayout(false);
            this.TSProfileGroupbox.ResumeLayout(false);
            this.TSProfileGroupbox.PerformLayout();
            this.TSAddLecturesPanel.ResumeLayout(false);
            this.TSders_verListViewGroupbox.ResumeLayout(false);
            this.TSotherGroupbox.ResumeLayout(false);
            this.TSotherGroupbox.PerformLayout();
            this.stdControlPanel.ResumeLayout(false);
            this.stdLecturesPanel.ResumeLayout(false);
            this.stdLecturesShowGroupbox.ResumeLayout(false);
            this.stdOldLecturesPanel.ResumeLayout(false);
            this.stdOldLecturesListviewGroupbox.ResumeLayout(false);
            this.stdPointsPanel.ResumeLayout(false);
            this.stdPointListViewGroupbox.ResumeLayout(false);
            this.stdLecturesAddPanel.ResumeLayout(false);
            this.stdLectureAddGroupbox.ResumeLayout(false);
            this.stdProfilePanel.ResumeLayout(false);
            this.stdProfileİnformationGroupbox.ResumeLayout(false);
            this.stdProfileİnformationGroupbox.PerformLayout();
            this.stdControlTransactionGroupbox.ResumeLayout(false);
            this.periodPanel.ResumeLayout(false);
            this.PeriodInsertGroupbox.ResumeLayout(false);
            this.PeriodInsertGroupbox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel loginPanel;
        private System.Windows.Forms.GroupBox LogInGroupBox;
        private System.Windows.Forms.PictureBox STATUpictureBox;
        private System.Windows.Forms.PictureBox PSWpictureBox;
        private System.Windows.Forms.PictureBox IDpictureBox;
        private System.Windows.Forms.ComboBox STATUcomboBox;
        private System.Windows.Forms.TextBox PSWtxtbox;
        private System.Windows.Forms.TextBox IDtxtbox;
        private System.Windows.Forms.Button LogInbtn;
        private System.Windows.Forms.Panel adminPanel;
        private System.Windows.Forms.Button teachingstaffaddPanelbtn;
        private System.Windows.Forms.Button logOutbtn;
        private System.Windows.Forms.Button deletebtn;
        private System.Windows.Forms.Button studentAddPanelBtn;
        private System.Windows.Forms.Button studentsbtn;
        private System.Windows.Forms.Button teachingstaffsbtn;
        private System.Windows.Forms.Panel teachingstaffAddpanel;
        private System.Windows.Forms.TextBox TSsurnameTxtbox;
        private System.Windows.Forms.TextBox TStc_noTxtbox;
        private System.Windows.Forms.TextBox TSpswTxtbox;
        private System.Windows.Forms.TextBox TSnameTxtbox;
        private System.Windows.Forms.Label TStc_noLabel;
        private System.Windows.Forms.Label TSpswlabel;
        private System.Windows.Forms.Label TSsurnamelabel;
        private System.Windows.Forms.Label TSnamelabel;
        private System.Windows.Forms.Label TSprogramsLabel;
        private System.Windows.Forms.ComboBox TSprogramsCombobox;
        private System.Windows.Forms.GroupBox Teachingstaffaddgroupbox;
        private System.Windows.Forms.Button TSaddPanelBackbtn;
        private System.Windows.Forms.Button TSaddBTN;
        private System.Windows.Forms.Panel StdaddPanel;
        private System.Windows.Forms.Label stdProgramsLabel;
        private System.Windows.Forms.Label stdPswLabel;
        private System.Windows.Forms.Label stdTc_noLabel;
        private System.Windows.Forms.Label stdSurnameLabel;
        private System.Windows.Forms.Label stdNameLabel;
        private System.Windows.Forms.ComboBox stdProgramsCombobox;
        private System.Windows.Forms.TextBox stdPswTxtbox;
        private System.Windows.Forms.TextBox stdSurnameTxtbox;
        private System.Windows.Forms.TextBox stdTc_noTxtbox;
        private System.Windows.Forms.TextBox stdNameTxtbox;
        private System.Windows.Forms.Button stdAddPanelBackBtn;
        private System.Windows.Forms.Button stdAddBtn;
        private System.Windows.Forms.GroupBox stdAddGroupbox;
        private System.Windows.Forms.Panel dellPanel;
        private System.Windows.Forms.Button dellPanelBackBtn;
        private System.Windows.Forms.Button dellBtn;
        private System.Windows.Forms.Label dellIdLabel;
        private System.Windows.Forms.Label dellStatuLabel;
        private System.Windows.Forms.TextBox dellIdTxtbox;
        private System.Windows.Forms.ComboBox dellStatuCombobox;
        private System.Windows.Forms.Panel TSgridViewPanel;
        private System.Windows.Forms.GroupBox TSsearchGroupbox;
        private System.Windows.Forms.Button TSgridViewSearchbtn;
        private System.Windows.Forms.Label TSgridViewSearchLabel;
        private System.Windows.Forms.TextBox TSgridViewSearchTxtbox;
        private System.Windows.Forms.GroupBox TSgridViewGroupbox;
        private System.Windows.Forms.Button TSgridViewBackBtn;
        private System.Windows.Forms.DataGridView TSgridView;
        private System.Windows.Forms.Panel stdGridViewPanel;
        private System.Windows.Forms.Button stdGridViewBackBtn;
        private System.Windows.Forms.GroupBox stdGridViewSearchGroupbox;
        private System.Windows.Forms.Button stdGridViewSearchBtn;
        private System.Windows.Forms.Label stdGridViewSearcLabel;
        private System.Windows.Forms.TextBox stdGridViewSearchTxtbox;
        private System.Windows.Forms.GroupBox stdGridViewGroupbox;
        private System.Windows.Forms.DataGridView stdDataGridView;
        private System.Windows.Forms.Panel TScontrolPanel;
        private System.Windows.Forms.GroupBox TScontrolGroupbox;
        private System.Windows.Forms.ListView TSLectureAddListView;
        private System.Windows.Forms.Button TSLecturesaddbtn;
        private System.Windows.Forms.Button TSlecturesPanelBackBtn;
        private System.Windows.Forms.GroupBox TSotherGroupbox;
        private System.Windows.Forms.Label TSLoginWelcomeLabel;
        private System.Windows.Forms.Button TSnoticePanelBtn;
        private System.Windows.Forms.Button TSexamsPanelBtn;
        private System.Windows.Forms.GroupBox TSlecturesGroupbox;
        private System.Windows.Forms.Button TSlecturesShowBtn;
        private System.Windows.Forms.ListView TSLecturesListView;
        private System.Windows.Forms.GroupBox TSders_verListViewGroupbox;
        private System.Windows.Forms.Button TSders_verAddBtn;
        private System.Windows.Forms.GroupBox TSpointsAddGroupbox;
        private System.Windows.Forms.Label TSpointsAddFinalLabel;
        private System.Windows.Forms.Label TSpointsAddVizeLabel;
        private System.Windows.Forms.TextBox TSpointsAddFinalTextbox;
        private System.Windows.Forms.Button TSpointsAddBtn;
        private System.Windows.Forms.TextBox TSpointsAddVizeTextbox;
        private System.Windows.Forms.ListView TSpointsAddListview;
        private System.Windows.Forms.ListView TSpointsLecturesListView;
        private System.Windows.Forms.GroupBox TSpointsAddGroupbox2;
        private System.Windows.Forms.Panel stdControlPanel;
        private System.Windows.Forms.Panel stdLecturesPanel;
        private System.Windows.Forms.ListView stdLecturesShowListView;
        private System.Windows.Forms.GroupBox stdControlTransactionGroupbox;
        private System.Windows.Forms.Button stdControlPanelBackBtn;
        private System.Windows.Forms.Button stdLecturesPanelBtn;
        private System.Windows.Forms.Button stdProfilePanelBtn;
        private System.Windows.Forms.Button stdLecturesAddPanelBtn;
        private System.Windows.Forms.Button stdPointsPanelBtn;
        private System.Windows.Forms.Panel stdLecturesAddPanel;
        private System.Windows.Forms.Button stdLecturesAddBtn;
        private System.Windows.Forms.ListView stdLecturesAddListView;
        private System.Windows.Forms.GroupBox stdLectureAddGroupbox;
        private System.Windows.Forms.Panel stdPointsPanel;
        private System.Windows.Forms.ListView stdPointListView;
        private System.Windows.Forms.GroupBox stdLecturesShowGroupbox;
        private System.Windows.Forms.Button forgotPswBtn;
        private System.Windows.Forms.GroupBox stdPointListViewGroupbox;
        private System.Windows.Forms.Panel stdProfilePanel;
        private System.Windows.Forms.GroupBox stdProfileİnformationGroupbox;
        private System.Windows.Forms.Button stdProfileNewSecurityWordPanelBtn;
        private System.Windows.Forms.Button stdProfileNewPswPanelBtn;
        private System.Windows.Forms.Label stdProfileInputSecurityWordLabel;
        private System.Windows.Forms.Label stdProfileInputPswLabel;
        private System.Windows.Forms.Label stdProfileInputProgramsLabel;
        private System.Windows.Forms.Label stdProfileInputsurnameLabel;
        private System.Windows.Forms.Label stdProfileInputNameLabel;
        private System.Windows.Forms.Label stdProfileSecurityWordLabel;
        private System.Windows.Forms.Label stdProfilePswLabel;
        private System.Windows.Forms.Label stdProfileProgramsLabel;
        private System.Windows.Forms.Label stdProfileSurnameLabel;
        private System.Windows.Forms.Label stdProfileNameLabel;
        private System.Windows.Forms.Button stdNewPswBtn;
        private System.Windows.Forms.Button stdNewSecurityWordBtn;
        private System.Windows.Forms.TextBox stdNewSecurityWordTextbox;
        private System.Windows.Forms.TextBox stdNewPswTextbox;
        private System.Windows.Forms.Panel TSlecturesPanel;
        private System.Windows.Forms.Panel TSAddLecturesPanel;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel TSProfilePanel;
        private System.Windows.Forms.Button TSProfileAddNewSecurityWordBtn;
        private System.Windows.Forms.Button TSProfileAddNewPswBtn;
        private System.Windows.Forms.Button TSProfileNewSecurityWordBtn;
        private System.Windows.Forms.Button TSProfileNewPswBtn;
        private System.Windows.Forms.TextBox TSProfileNewSecurityWordTextbox;
        private System.Windows.Forms.TextBox TSProfileNewPswTextbox;
        private System.Windows.Forms.Label TSProfileInputSecurityWordLabel;
        private System.Windows.Forms.Label TSProfileInputPswLabel;
        private System.Windows.Forms.Label TSProfileInputProgramsLabel;
        private System.Windows.Forms.Label TSProfileInputSurnameLabel;
        private System.Windows.Forms.Label TSProfileInputNameLabel;
        private System.Windows.Forms.Label TSProfileSecurityWordLabel;
        private System.Windows.Forms.Label TSProfilePswLabel;
        private System.Windows.Forms.Label TSProfilProgramsLabel;
        private System.Windows.Forms.Label TSProfileSurnameLabel;
        private System.Windows.Forms.Label TSProfileNameLabel;
        private System.Windows.Forms.GroupBox TSProfileGroupbox;
        private System.Windows.Forms.Panel TSpointsPanel;
        private System.Windows.Forms.GroupBox adminControlPanelGroupbox;
        private System.Windows.Forms.Label stdSecurityWordLabel;
        private System.Windows.Forms.TextBox stdSecurityWordTextbox;
        private System.Windows.Forms.GroupBox dellGroupbox;
        private System.Windows.Forms.Label TSsecurityWordLabel;
        private System.Windows.Forms.TextBox TSsecurityWordTextbox;
        private System.Windows.Forms.Button CloseBtn;
        private System.Windows.Forms.Panel loginPanelİdPanel;
        private System.Windows.Forms.Panel loginPanelPswPanel;
        private System.Windows.Forms.GroupBox dellInputGroupbox;
        private System.Windows.Forms.DataGridView dellDatagridView;
        private System.Windows.Forms.GroupBox TSgridViewUpdateGroupbox;
        private System.Windows.Forms.Button TSgridViewUpdateBtn;
        private System.Windows.Forms.Label TSgridViewUpdateTcNoLabel;
        private System.Windows.Forms.Label TSgridViewUpdateSurnameLabel;
        private System.Windows.Forms.Label TSgridViewUpdateNameLabel;
        private System.Windows.Forms.TextBox TSgridViewUpdateTCNoTextbox;
        private System.Windows.Forms.TextBox TSgridViewUpdateNameTextbox;
        private System.Windows.Forms.TextBox TSgridViewUpdateSurnameTextbox;
        private System.Windows.Forms.GroupBox stdGridviewUpdateGroupbox;
        private System.Windows.Forms.Button stdGridViewUpdateBtn;
        private System.Windows.Forms.Label stdGridViewUpdateTCNoLabel;
        private System.Windows.Forms.Label stdGridViewUpdateSurnameLabel;
        private System.Windows.Forms.Label stdGridViewUpdateNameLabel;
        private System.Windows.Forms.TextBox stdGridViewUpdateTCNoTextbox;
        private System.Windows.Forms.TextBox stdGridViewUpdateNameTextbox;
        private System.Windows.Forms.TextBox stdGridViewUpdateSurnameTextbox;
        private System.Windows.Forms.Button adminPanelPeriodFinish;
        private System.Windows.Forms.Panel periodPanel;
        private System.Windows.Forms.GroupBox PeriodInsertGroupbox;
        private System.Windows.Forms.Button PeriodInsertBtn;
        private System.Windows.Forms.ComboBox PeriodInsertNamecomboBox;
        private System.Windows.Forms.Label periodInsertNameLabel;
        private System.Windows.Forms.Panel stdOldLecturesPanel;
        private System.Windows.Forms.ListView stdOldLecturesPanellistView;
        private System.Windows.Forms.Button stdOldLecturesPanelbtn;
        private System.Windows.Forms.GroupBox stdOldLecturesListviewGroupbox;
        private System.Windows.Forms.Button periodPanelBackBtn;
        private System.Windows.Forms.Button stdOldLecturesAddBtn;
    }
}

